let employee = {
    name: "Saurabh",
    age: 30,
    department: "QA"
};

console.log(employee.name)