let fruits =["Guava","Mango",10,false,679.76]
console.log(fruits[0])
console.log(fruits.length)

let x=[]
x.push(45)
x.push(90)
console.log(x)

x.pop();
console.log(x)
