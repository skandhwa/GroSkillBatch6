let fruits=["Mango","Apple"]
fruits.unshift("Guava")
fruits.unshift("Kiwi")
console.log(fruits)

fruits.shift()
console.log(fruits)