let name="Saurabh"

let x=`Hello world`

let age="50"

console.log(`My name is ${name} and my age is ${age}`);