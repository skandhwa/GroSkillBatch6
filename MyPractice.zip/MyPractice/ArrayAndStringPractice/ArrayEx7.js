const numbers = [40, 100, 1, 5, 25, 10];
numbers.sort((a, b) => b - a); 
console.log(numbers); 



