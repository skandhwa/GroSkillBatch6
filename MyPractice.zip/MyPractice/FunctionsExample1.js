function test()
{
    console.log("I am test function")
}

test();/// Basic Function