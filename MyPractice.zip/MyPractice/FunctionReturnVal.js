function add(a,b,c)
{
    return a+b+c
}
console.log (add(10,20,30))




