let add=(a,b,c) => a+b+c;
console.log(add(30,40,80));



function add(a,b,c)
{
    return a+b+c
}
console.log (add(10,20,30))