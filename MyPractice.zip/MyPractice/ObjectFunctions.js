const person={
 
    name:"harry",
    show()
    {
        console.log(`hello I am Mr, ${this.name}`);
    }

}

person.show()


