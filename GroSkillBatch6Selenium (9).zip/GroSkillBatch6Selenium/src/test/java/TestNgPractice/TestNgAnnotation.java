package TestNgPractice;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TestNgAnnotation {
	
	@AfterTest
	public void test1()
	{
		System.out.println("I am after test");//6
	}
	
	@AfterMethod
	public void test12()
	{
		System.out.println("I am after Method");//4
	}
	
	
	@AfterClass
	public void test3()
	{
		System.out.println("I am after class");//5
	}
	
	@BeforeClass
	public void test4()
	{
		System.out.println("I am before class");//1
	}
	
	@BeforeMethod
	public void test5()
	{
		System.out.println("I am before method");//2
	}
	
	@Test
	public void test6()
	{
		System.out.println("I am Test");//3
	}
	
	

}
