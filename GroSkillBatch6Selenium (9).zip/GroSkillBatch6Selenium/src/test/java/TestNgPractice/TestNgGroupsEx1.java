package TestNgPractice;

import org.testng.annotations.Test;

public class TestNgGroupsEx1 {
	
	@Test(groups="regression")
	public void test1()
	{
		System.out.println("I am regression test1");
	}
	
	
	@Test(groups="sanity")
	public void test2()
	{
		System.out.println("I am sanity test2");
	}
	
	@Test(groups="regression")
	public void test3()
	{
		System.out.println("I am regression test3");
	}
	
	@Test(groups="sanity")
	public void test4()
	{
		System.out.println("I am sanity test4");
	}
	

}
