package UsingChromeOptions;

import java.util.LinkedHashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

public class UsingChromeOptionForMobile {

	public static void main(String[] args) {
		
		Map<String,String> mbE=new LinkedHashMap<String,String>();
		
		mbE.put("deviceName", "iphone17");
		
		ChromeOptions opt=new ChromeOptions();
		
		opt.setExperimentalOption("mymobileEmulator",mbE);
		
		
//		DesiredCapabilities cap=new DesiredCapabilities();
//		cap.setCapability("myphone", "iphone17");
//		
//		WebDriver driver=new ChromeDriver();
//		

	}

}
