package UsingChromeOptions;

import java.util.LinkedHashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class DownloadAtSpecifcLocation {

	public static void main(String[] args) {
		
		Map<String,Object> mp=new LinkedHashMap<String,Object>();
		mp.put("my_download","D://Test1");
		
		ChromeOptions opt=new ChromeOptions();
		
		opt.setExperimentalOption("my location to download",mp);
		
		WebDriver driver=new ChromeDriver(opt);

	}

}
