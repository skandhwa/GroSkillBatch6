package UsingChromeOptions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class HandlingChromeOptions2 {

	public static void main(String[] args) {
		 ChromeOptions opt=new ChromeOptions();
		  opt.addArguments("--start-maximized");
			//opt.addArguments("--headless=new");
		  
		 // opt.addArguments("--incognito");
		  opt.addArguments("--disable-notifications");
		  opt.setAcceptInsecureCerts(true);
		  opt.addArguments("--disable-extensions");
		  opt.addArguments("--disable-popup-blocking");
		  opt.addArguments("--window-size=2048,2000");
		  
		  
			
	       WebDriver driver=new ChromeDriver(opt);
	       driver.get("https://www.saucedemo.com/");
	       driver.findElement(By.xpath("//input[@id='user-name']")).sendKeys("standard_user");
	       driver.findElement(By.xpath("//input[@id='password']")).sendKeys("secret_sauce");
	       driver.findElement(By.xpath("//input[@id='login-button']")).click();
	       
	    String title=   driver.getTitle();       
	    System.out.println("Title of page is  "+title);   

	}

}
