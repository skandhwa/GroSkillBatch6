Feature: Validate user searches an item and add it to cart

  Background: 
    Given user opens the Ecomm application
    And user enters the username in uname field
    And user enters the password in pwd field
    When user clicks on the login button of the application
    Then User will be navigated to homepage of the application

@smoke
  Scenario: Validate addition for Electronic item
    And user searches an electronic item
    And user add it to cart

  Scenario: Validate addition for Lifestylewear item
    And user searches an Lifestylewear item
    And user add it to cart

  Scenario: Validate addition for footwear item
    And user searches an footwear item
    And user add it to cart
