Feature: Validate creation of Data Table Cucumber

  Scenario: Validate new user creation Data Table
    Given user opens the login page
    And user enters the below details
      | firstname | lastname | Address  | emailAddress    | phone      |
      | harry     | dsouza   | TM nagar | abccd@gmail.com | 9067543217 |
