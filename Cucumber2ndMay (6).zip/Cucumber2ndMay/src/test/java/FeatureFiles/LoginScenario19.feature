Feature: Validate Login functionality for FB Application with multiple credentials

@regression 

  Scenario Outline: Login Scenario Validation with multiple correct credentails
    Given user opens the FB application
    And user enters the username in uname field as "<username>"
    And user enters the password in pwd field as "<password>"
    When user clicks on the login button of the application
    Then User will be navigated to homepage of the application

    Examples: 
      | username | password  |
      | test123  | test@1234 |
      | test456  | test@456  |
      | test789  | test@789  |
