package StepDefinition22;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions
(
		features="src/test/java/FeatureFiles/",
		glue= {"StepDefinition22"},
		tags="@regression and @smoke",
		dryRun=true,
		monochrome=true,
		
		plugin= {"pretty","html:target/HTMLReports/index.html"}
		
		)






public class TestRunner25 {

}
