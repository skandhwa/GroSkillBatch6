package RequestResponseSpecification2;

import static io.restassured.RestAssured.given;

import PayloadData.Payload;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class ReUse {
	
	public static  RequestSpecification postReq()
	{
		RequestSpecification req=new RequestSpecBuilder().
				setBaseUri("https://reqres.in")
				.setContentType(ContentType.JSON)
				.setRelaxedHTTPSValidation().
				addHeader("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8")
				.build();
		
		RequestSpecification req1=given().log().all().spec(req).body(Payload.addEmployeeDetails("Tom","Manager"));
		return req1;
	}
	
	public static  RequestSpecification getReq()
	{
		RequestSpecification req=new RequestSpecBuilder().
				setBaseUri("https://reqres.in")
				.setContentType(ContentType.JSON)
				.setRelaxedHTTPSValidation().
				addHeader("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8")
				.build();
		
		return req;
	}
	
	
	
	public static ResponseSpecification getRes(int statuscode)
	{
		ResponseSpecification res=new ResponseSpecBuilder().
				expectStatusCode(statuscode).expectContentType(ContentType.JSON)
				.build();
		
		return res;
	}
	
	public static  RequestSpecification postReq2()
	{
		RequestSpecification req=new RequestSpecBuilder().
				setBaseUri("https://reqres.in")
				.setContentType(ContentType.JSON)
				.setRelaxedHTTPSValidation().
				addHeader("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8")
				.build();
		
		RequestSpecification req1=given().log().all().spec(req);
		return req1;
	}
	
	

}
