package APISK10Serialization5;

public class EmployeeAddressPOJO {
	
	private HouseDetailsPOJO hdPObj;
	private int zip;
	private String state;
	private String city;
	
	public HouseDetailsPOJO getHdPObj() {
		return hdPObj;
	}
	public void setHdPObj(HouseDetailsPOJO hdPObj) {
		this.hdPObj = hdPObj;
	}
	public int getZip() {
		return zip;
	}
	public void setZip(int zip) {
		this.zip = zip;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	
	

}
