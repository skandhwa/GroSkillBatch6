package APISK10Serialization5;

import static io.restassured.RestAssured.given;

import java.net.http.HttpTimeoutException;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class CreateEmployee5 {

	public static void main(String[] args) throws JsonProcessingException, HttpTimeoutException {
		
		FlatDetailsPOJO fltObj=new FlatDetailsPOJO();
		fltObj.setFlatName("Prem Villa");
		fltObj.setFlatNo(34);
		fltObj.setFloorNo(3);
		
		List<String> landmark=new ArrayList<String>();
		landmark.add("ABC Sweets");
		landmark.add("JK hotel");
		landmark.add("BMC mall");
		
		HouseDetailsPOJO hdObj=new HouseDetailsPOJO();
		hdObj.setFltObj(fltObj);
		hdObj.setStreet("MG Road");
		hdObj.setLandmark(landmark);
		
		
		EmployeeAddressPOJO empPOJO=new EmployeeAddressPOJO();
		empPOJO.setHdPObj(hdObj);
		empPOJO.setCity("Delhi");
		empPOJO.setState("NCR");
		empPOJO.setZip(10067);
		
		List<String> li=new ArrayList<String>();
		li.add("SBI");
		li.add("HDFC");
		li.add("BOB");
		
		EmployeePOJO5 emp=new EmployeePOJO5();
		emp.setName("Harry");
		emp.setAge(45);
		emp.setSalary(90000);
		emp.setEmpObj(empPOJO);
		emp.setBanks(li);
		
		ObjectMapper obj=new ObjectMapper();
		
	String empJSON=	obj.writerWithDefaultPrettyPrinter().writeValueAsString(emp);
		
		
RestAssured.baseURI="https://reqres.in";
	
	Response res=	given().log().all()
		.headers("content-type","application/json").
		headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8")
		.body(empJSON)
		
		
		.when().post("api/users")
		.then().log().all().
		assertThat().statusCode(201)
		.extract().response();
	
	long time=res.getTime();
	
	if(time>5000)
	{
		throw new HttpTimeoutException("Time limit exceeded");
	}
	
	else{
		
		System.out.println("Test case passed");
		
	}
	
	
	
	System.out.println(res.asString());
		
		
		
		
		
		
		
		

	}

}
