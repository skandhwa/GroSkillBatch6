package APISK10_ExcelIntegrationRestAssured;

public class ConstantsData {
	
	public static final String EXCEL_PATH="D:/TestData1stJune.xlsx";
	public static final String SHEET_NAME="Sheet1";
	
	

}
