package APISK10_DBIntegration;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.testng.annotations.Test;

public class CreateConnectionDB {
	
	@Test
	public static Object createConnection(int colIndex) throws SQLException
	{
		Connection con=null;
		Statement myst=null;
		ResultSet myRs=null;
		Object obj=null;
		
	con=	DriverManager.getConnection("jdbc:mysql://localhost:3306/apisk08","root","root");
	myst=	con.createStatement();
	
	myRs=myst.executeQuery("select * from apisk08.employees limit 1;");
	
	while(myRs.next())
	{
		obj=myRs.getString(colIndex);
	}
	
	
	return obj;
		
		
	}
	
	

}
