package MyPractice1;

import static io.restassured.RestAssured.given;

import PayloadData.Payload;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class PostRequestEx {

	public static void main(String[] args) throws Exception {
		
		RestAssured.baseURI="https://reqres.in";
		
		 Response res=		given().log().all().
				headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8").
				headers("content-type","application/json").
				body(Payload.addEmployeeDetails("harry","QA manager")).
				
				
				
				when().post("api/users").
			    then().log().all().assertThat().statusCode(201)
			    .extract().response();
		 
		long time= res.getTime();
		
		System.out.println(time);
		
		if(time>5000)
		{
			throw new Exception("Time limit exceeded");
		}
		else
		{
			System.out.println("Test case passed");
		}
		 
		 

	}

		

	}

