package MyPractice1;

import static io.restassured.RestAssured.given;

import org.testng.Assert;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;


public class MyTest1 {

	public static void main(String[] args) {
		
		RestAssured.baseURI="https://reqres.in";
		
 String Response=		given().log().all().
		headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8").
		headers("content-type","application/json").
		when().get("api/users/2").
	    then().log().all().extract().response().asString();
 
 System.out.println(Response);
 
JsonPath js=new JsonPath(Response);
 
 String LastName=js.get("data.last_name");
 Assert.assertEquals("Weaver", LastName);
 
 
 
 
 
 
 
 
 
 
 
 





	}

}
