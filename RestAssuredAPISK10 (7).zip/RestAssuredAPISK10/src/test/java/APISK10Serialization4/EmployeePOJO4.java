package APISK10Serialization4;

import java.util.List;

public class EmployeePOJO4 {
	
	private String name;
	private int id;
	private double salary;
	private EmployeeAddress4 empAddress4;
	private List<String> banks;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public EmployeeAddress4 getEmpAddress4() {
		return empAddress4;
	}
	public void setEmpAddress4(EmployeeAddress4 empAddress4) {
		this.empAddress4 = empAddress4;
	}
	public List<String> getBanks() {
		return banks;
	}
	public void setBanks(List<String> banks) {
		this.banks = banks;
	}
	
	
	
	
	

}
