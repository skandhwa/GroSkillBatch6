package APISK10Serialization4;

import static io.restassured.RestAssured.given;

import java.net.http.HttpTimeoutException;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class CreateEmployee4 {

	public static void main(String[] args) throws JsonProcessingException, HttpTimeoutException {
		EmployeeAddress4 empAddress=new EmployeeAddress4();
		
		empAddress.setCity("Delhi");
		empAddress.setState("NCR");
		empAddress.setZip(713304);
		
		List<String> li=new ArrayList<String>();
		li.add("SBI");
		li.add("HDFC");
		li.add("YesBank");
		
		
		EmployeePOJO4 empPojo4=new EmployeePOJO4();
		empPojo4.setName("Harry");
		empPojo4.setId(7565);
		empPojo4.setSalary(70000);
		empPojo4.setBanks(li);
		empPojo4.setEmpAddress4(empAddress);
		
		ObjectMapper obj=new ObjectMapper();
	String empJSON=	obj.writerWithDefaultPrettyPrinter().writeValueAsString(empPojo4);
		
RestAssured.baseURI="https://reqres.in";
	
	Response res=	given().log().all()
		.headers("content-type","application/json").
		headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8")
		.body(empJSON)
		
		
		.when().post("api/users")
		.then().log().all().
		assertThat().statusCode(201)
		.extract().response();
	
	long time=res.getTime();
	
	if(time>5000)
	{
		throw new HttpTimeoutException("Time limit exceeded");
	}
	
	else{
		
		System.out.println("Test case passed");
		
	}
	
	
	
	System.out.println(res.asString());
	

	}

}
