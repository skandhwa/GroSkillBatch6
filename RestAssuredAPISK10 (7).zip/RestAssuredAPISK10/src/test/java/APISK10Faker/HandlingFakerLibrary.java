package APISK10Faker;

import java.net.http.HttpTimeoutException;
import java.util.LinkedHashMap;
import java.util.Map;

import io.restassured.RestAssured;
import io.restassured.RestAssured.*;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;
import com.github.javafaker.Faker;
import com.github.javafaker.IdNumber;

import APISK10_Payload.Payload;

public class HandlingFakerLibrary {

	public static void main(String[] args) throws HttpTimeoutException {
		
		Faker fake=new Faker();
		
		String fullName=fake.name().fullName();
		String emailAddress= fake.internet().emailAddress();
		IdNumber id=fake.idNumber();
		long salary=fake.number().randomNumber();
		String phone=fake.phoneNumber().cellPhone();
		
		Map<String,Object> mp=new LinkedHashMap<String,Object>();
		
		mp.put("name",fullName );
		mp.put("emailAddress", emailAddress);
		mp.put("id", id);
		mp.put("salary", salary);
		mp.put("phone", phone);
		

		RestAssured.baseURI="https://reqres.in";
		
	Response res=	given().log().all()
		.headers("content-type","application/json").
		headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8")
		.body(mp)
		
		
		.when().post("api/users")
		.then().assertThat().statusCode(201)
		.extract().response();
	
	long time=res.getTime();
	
	if(time>5000)
	{
		throw new HttpTimeoutException("Time limit exceeded");
	}
	
	else{
		
		System.out.println("Test case passed");
		
	}
	
	
	
	System.out.println(res.asString());
		
		
		
		

	}

}
