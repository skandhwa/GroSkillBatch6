package POJOEx4;

import static io.restassured.RestAssured.given;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;

public class CreateEmployee4 {

	public static void main(String[] args) throws JsonProcessingException {
	
		
		
		EmployeePOJO4 emp=new EmployeePOJO4();
		emp.setName("Harry");
		emp.setJob("QA lead");
		emp.setMarried(false);
		emp.setSalary(80000);
		
		EmployeePOJO4 emp2=new EmployeePOJO4();
		emp2.setName("Tom");
		emp2.setJob("QA Analyst");
		emp2.setMarried(true);
		emp2.setSalary(70000);
		
		
		EmployeePOJO4 emp3=new EmployeePOJO4();
		emp3.setName("Matt");
		emp3.setJob("QA Eng");
		emp3.setMarried(false);
		emp3.setSalary(60000);
		
		
		List<EmployeePOJO4> li=new ArrayList<EmployeePOJO4>();
		li.add(emp);
		li.add(emp2);
		li.add(emp3);
		
		ObjectMapper obj=new ObjectMapper();
	String empJSON=	obj.writerWithDefaultPrettyPrinter().writeValueAsString(li);
		
		
	RestAssured.baseURI="https://reqres.in";
	
	 String res=		given().log().all().
			headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8").
			headers("content-type","application/json").
			body(empJSON).when().post("api/users").
		    then().log().all().assertThat().statusCode(201)
		    .extract().response().asString();
	 
	 System.out.println(res);
	 
		
		
		

	}

}
