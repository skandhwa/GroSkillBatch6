package HandlingDBConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.testng.annotations.Test;

public class CreateConnection {
	
	@Test
	
	public static Object createConnection(int colIndex) throws SQLException
	{
	
	
	Connection con=null;
	Statement mystmt=null;
	ResultSet myRs=null;
	Object obj=null;
	try
	{
	con=DriverManager.getConnection("jdbc:mysql://localhost:3306/apisk08","root","root");
	mystmt=con.createStatement();
	
	myRs=mystmt.executeQuery("select * from apisk08.employees limit 1");
	
	while(myRs.next())
	{
	 obj=	myRs.getString(colIndex);
	}
	
	return obj;
	
	}
	
	
	finally
	{
		con.close();
	}
	
	
	
	
	
	
	
	
	
	
	}
	
	
	
	

}
