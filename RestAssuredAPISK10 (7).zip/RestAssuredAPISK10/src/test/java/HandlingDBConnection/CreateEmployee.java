package HandlingDBConnection;

import static io.restassured.RestAssured.given;

import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

import io.restassured.RestAssured;

public class CreateEmployee {

	public static void main(String[] args) throws SQLException {
		
		
		Map<String,Object> mp=new LinkedHashMap<String,Object>();
		mp.put("id",CreateConnection.createConnection(1));
		mp.put("name",CreateConnection.createConnection(2)); 
		mp.put("address", CreateConnection.createConnection(3));
		mp.put("age", CreateConnection.createConnection(4));
		mp.put("salary", CreateConnection.createConnection(5));
		mp.put("status", CreateConnection.createConnection(6));
		
		
		RestAssured.baseURI="https://reqres.in";
		
		 String res=		given().log().all().
				headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8").
				headers("content-type","application/json").
				body(mp).when().post("api/users").
			    then().log().all().assertThat().statusCode(201)
			    .extract().response().asString();
		 
		 System.out.println(res);
		 
		
		
		
		

	}

}
