package APISK10;

import static io.restassured.RestAssured.given;

import java.util.concurrent.TimeoutException;

import org.testng.Assert;
import org.testng.annotations.Test;

import APISK10_Payload.Payload;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class ValidatingDynamicResponse {
	
	@Test
	public void validateBookDetails() throws TimeoutException
	{
		String isbn="" + (char)('a' + Math.random()*26) + (char)('a' + Math.random()*26) + (char)('a' + Math.random()*26);
		
		String aisle=String.valueOf((int)(Math.random() * 900) + 100);
		
		String ID=isbn+aisle;
		
		RestAssured.baseURI="http://216.10.245.166";
		
		
		Response res=	given().log().all()
		.headers("content-type","application/json")
		.body(Payload.AddBook(isbn,aisle))
		.when().post("Library/Addbook.php")
		.then().log().all().
		assertThat().statusCode(200)
		.extract().response();
		
		long time=  res.getTime();
		
		if(time >5000)
		{
			throw new TimeoutException("Taking longer than expected time");
		}
		else
		{
			System.out.println("Test case passed");
		}
		
		String responseString=res.asString();
		
		System.out.println(res.asString());
		
		JsonPath js=new JsonPath(responseString);
		
		
	String message=	js.getString("Msg");
	Assert.assertEquals("successfully added", message);
	
	
	String id=js.getString("ID");
	Assert.assertEquals(ID,id);
	
	System.out.println("Test case passed");
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	
	
	

}
