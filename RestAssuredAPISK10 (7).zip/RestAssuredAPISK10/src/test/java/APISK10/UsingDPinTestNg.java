package APISK10;

import static io.restassured.RestAssured.given;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import APISK10_Payload.Payload;
import io.restassured.RestAssured;
import io.restassured.response.Response;

public class UsingDPinTestNg {

	@DataProvider(name="booksData")
	public Object [][] getData()
	{
		return new Object [][]
				{
			{"Appium Overview","tgft","6785"},
			{"RestAssured in Depth","fres","5432"},
			{"Selenium Details","jhgw","8281"}
				};
				
	}
	
	@Test(dataProvider="booksData")
	public void addBook(String bookName,String isbn,String aisle)
	{
RestAssured.baseURI="http://216.10.245.166";
		
		
		Response res=	given().log().all()
		.headers("content-type","application/json")
		.body(Payload.AddBook(isbn,aisle))
		.when().post("Library/Addbook.php")
		.then().log().all().
		assertThat().statusCode(200)
		.extract().response();
		
		String responseString=res.asString();
		System.out.println(responseString);
		
		
	}
	
	
	
	
	
	

}
