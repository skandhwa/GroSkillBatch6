package POJOEx1;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import static io.restassured.RestAssured.*;
import RequestResponseSpecification2.ReUse;

public class CreateEmployee1 {

	public static void main(String[] args) throws JsonProcessingException {
		
		EmployeePOJO1 emp=new EmployeePOJO1();
		emp.setName("Harry");
		emp.setJob("ITA");
		emp.setSalary(80000f);
		emp.setMarried(false);
		
		ObjectMapper obj=new ObjectMapper();
		
		///Serialization
	String empJSON=obj.writerWithDefaultPrettyPrinter().writeValueAsString(emp);
		
String Response=	given().log().all().spec(ReUse.postReq2()).body(empJSON)
	.when().post("api/users").then().assertThat().statusCode(201)
    .extract().response().asString();	

System.out.println(Response);

//System.out.println("Doing Deserialization");
//
//String name=empObj.getName();
//
//System.out.println(name);


		
		
		
		

	}

}
