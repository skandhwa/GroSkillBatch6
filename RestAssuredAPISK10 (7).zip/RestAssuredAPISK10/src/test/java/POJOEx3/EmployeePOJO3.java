package POJOEx3;

import java.util.List;

public class EmployeePOJO3 {
	
	private String name;
	private String job;
	private int salary;
	private EmployeeAddress3 empAddress;
	private List<String> banks;
	private boolean isMarried;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public EmployeeAddress3 getEmpAddress() {
		return empAddress;
	}
	public void setEmpAddress(EmployeeAddress3 empAddress) {
		this.empAddress = empAddress;
	}
	public List<String> getBanks() {
		return banks;
	}
	public void setBanks(List<String> banks) {
		this.banks = banks;
	}
	public boolean isMarried() {
		return isMarried;
	}
	public void setMarried(boolean isMarried) {
		this.isMarried = isMarried;
	}
	
	
	
	

}
