package APISK10_Payload;

public class Payload {
	
	public static String payloadData(String empName,String jobRole)
	{
		String empData="{\r\n"
				+ "    \"name\": \" "+empName+"   \",\r\n"
				+ "    \"job\": \"  "+jobRole+"      \"\r\n"
				+ "}";
		
		return empData;
	}
	
	
	public static String AddBook(String isbn,String aisle)
	{
		 
		
		String bookData ="{\r\n"
				+ "\r\n"
				+ "\"name\":\"Learn Appium Automation with Java\",\r\n"
				+ "\"isbn\":\""+isbn+"\",\r\n"
				+ "\"aisle\":\""+aisle+"\",\r\n"
				+ "\"author\":\"John foe\"\r\n"
				+ "}\r\n"
				+ "";
		
		return bookData;
	}
	
	
	
	

}
