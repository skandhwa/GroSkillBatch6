package APISK10Serialization2;

import static io.restassured.RestAssured.given;

import java.net.http.HttpTimeoutException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class CreateEmployee2 {

	public static void main(String[] args) throws JsonProcessingException, HttpTimeoutException {
		
		EmpAddressPOJO empAdd=new EmpAddressPOJO();
		
		empAdd.setCity("Delhi");
		empAdd.setStreet("MG Road");
		empAdd.setZipCode(713304);
		
		EmployeePOJO2 emp=new EmployeePOJO2();
		emp.setId(4567);
		emp.setName("Harry");
		emp.setSalary(90000);
		emp.setMarried(false);
		emp.setEmpAddressPOJO(empAdd);
		
		ObjectMapper obj=new ObjectMapper();
		
	String empJSON=	obj.writerWithDefaultPrettyPrinter().writeValueAsString(emp);
	System.out.println(empJSON);	
	
	RestAssured.baseURI="https://reqres.in";
	
	Response res=	given().log().all()
		.headers("content-type","application/json").
		headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8")
		.body(empJSON)
		
		
		.when().post("api/users")
		.then().log().all().
		assertThat().statusCode(201)
		.extract().response();
	
	long time=res.getTime();
	
	if(time>5000)
	{
		throw new HttpTimeoutException("Time limit exceeded");
	}
	
	else{
		
		System.out.println("Test case passed");
		
	}
	
	
	
	System.out.println(res.asString());
		
		
		
		
		

	}

}
