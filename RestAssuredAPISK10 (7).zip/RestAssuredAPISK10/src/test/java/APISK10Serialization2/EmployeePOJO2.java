package APISK10Serialization2;

public class EmployeePOJO2 {
	
	private String name;
	private int id;
	private double salary;
	private EmpAddressPOJO empAddressPOJO;
	private boolean isMarried;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public EmpAddressPOJO getEmpAddressPOJO() {
		return empAddressPOJO;
	}
	public void setEmpAddressPOJO(EmpAddressPOJO empAddressPOJO) {
		this.empAddressPOJO = empAddressPOJO;
	}
	public boolean isMarried() {
		return isMarried;
	}
	public void setMarried(boolean isMarried) {
		this.isMarried = isMarried;
	}
	
	
	
	

}
