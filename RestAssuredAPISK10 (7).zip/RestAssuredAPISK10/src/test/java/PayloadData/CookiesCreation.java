package PayloadData;

import java.util.LinkedHashMap;
import java.util.Map;

public class CookiesCreation {
	
	public static Map cookiesDetails()
	{
		Map<String,Object> mp=new LinkedHashMap<String,Object>();
		mp.put("userID", 876);
		mp.put("password", "test@1234");
		
		return mp;
		
		
		
	}
	
	

}
