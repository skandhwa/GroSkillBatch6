package ExcelIntegrationWithRestAssured;

public class ConstantData {
	
	public static final String EXCEL_PATH="D://TestData26thJan.xlsx";
	public static final String SHEET_NAME="Sheet1";
	
	

}
