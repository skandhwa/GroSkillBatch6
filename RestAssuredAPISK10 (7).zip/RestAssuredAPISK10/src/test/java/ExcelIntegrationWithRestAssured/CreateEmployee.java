package ExcelIntegrationWithRestAssured;

import static io.restassured.RestAssured.given;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import io.restassured.RestAssured;

public class CreateEmployee {

	public static void main(String[] args) throws IOException {
		
		FetchDataFromExcel obj=new FetchDataFromExcel(ConstantData.EXCEL_PATH,ConstantData.SHEET_NAME);
		Map<String,Object>mp=new LinkedHashMap<String,Object>();
		mp.put("id",FetchDataFromExcel.getDataExcel(1, 0));
		mp.put("name",FetchDataFromExcel.getDataExcel(1, 1));
		mp.put("address",FetchDataFromExcel.getDataExcel(1, 2));
		mp.put("salary",FetchDataFromExcel.getDataExcel(1, 3));
		
		RestAssured.baseURI="https://reqres.in";
		
		 String res=		given().log().all().
				headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8").
				headers("content-type","application/json").
				body(mp).when().post("api/users").
			    then().log().all().assertThat().statusCode(201)
			    .extract().response().asString();
		 
		 System.out.println(res);
		

	}

}
