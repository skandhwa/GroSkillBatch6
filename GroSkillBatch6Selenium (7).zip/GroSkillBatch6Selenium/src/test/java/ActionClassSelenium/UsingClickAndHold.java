package ActionClassSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class UsingClickAndHold {

	public static void main(String[] args) {
		 WebDriver driver = new ChromeDriver();

	        try {
	            driver.get("https://www.selenium.dev/selenium/web/mouse_interaction.html");

	            WebElement clickable =
	                    driver.findElement(By.id("clickable"));

	            Actions actions = new Actions(driver);

	            actions
	                .clickAndHold(clickable)
	                .pause(java.time.Duration.ofSeconds(2))
	                .release()
	                .perform();
	            
	           
	            

	        } finally {
	            driver.quit();
	        }
	    }
	}