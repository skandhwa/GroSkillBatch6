package ActionClassSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class FreeHandSignature {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://szimek.github.io/signature_pad/?utm_source=chatgpt.com");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.xpath("//div[@id='canvas-wrapper']"));
		
	Actions act=new Actions(driver);
	
	act.moveToElement(ele).clickAndHold().moveByOffset(50, 0)
	.moveByOffset(50,50)
	.moveByOffset(-50, 50)
	.moveByOffset(100, 0)
	
	
	.release().perform();
	

	}

}
