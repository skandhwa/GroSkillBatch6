package ActionClassSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class RightClickAction {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.guru99.com/test/simple_context_menu.html");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.xpath("//*[text()='right click me']"));

	Actions act=new Actions(driver);
	act.contextClick(ele).build().perform();
	Thread.sleep(2000);
	driver.findElement(By.xpath("//*[text()='Edit']")).click();
	driver.switchTo().alert().accept();
	driver.navigate().refresh();
	
WebElement ele1=	driver.findElement(By.xpath("//*[text()='Double-Click Me To See Alert']"));
Thread.sleep(2000);
	act.doubleClick(ele1).build().perform();
	
	
	
	
	
	}

}
