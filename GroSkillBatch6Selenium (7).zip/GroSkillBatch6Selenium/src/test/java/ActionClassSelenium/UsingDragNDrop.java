package ActionClassSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class UsingDragNDrop {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.selenium.dev/selenium/web/mouse_interaction.html");
		driver.manage().window().maximize();
	WebElement Src=	driver.findElement(By.xpath("//div[@id='draggable']"));
	WebElement target=	driver.findElement(By.xpath("//div[@id='droppable']"));
		
	Actions act=new Actions(driver);
	act.dragAndDrop(Src, target).build().perform();
	
	driver.navigate().refresh();
	
	Thread.sleep(8000);
	act.moveByOffset(550, 2000).build().perform();
		
		
		///   
		
		
		////   
		
		

	}

}
