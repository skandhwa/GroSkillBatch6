package UsingJavaScriptExecutor;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class EnterValueInTextBox {

	public static void main(String[] args) {
		
		WebDriver driver= new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
	WebElement ele=	driver.findElement(By.xpath("//input[@placeholder='First Name']"));
	WebElement ele1=	driver.findElement(By.xpath("//input[@placeholder='Last Name']"));  
	JavascriptExecutor js=(JavascriptExecutor)driver;
	js.executeScript(
		    "arguments[0].value='Saurabh'; arguments[1].value='Kandhway';",
		    ele,
		    ele1
		);
	
	}

}
