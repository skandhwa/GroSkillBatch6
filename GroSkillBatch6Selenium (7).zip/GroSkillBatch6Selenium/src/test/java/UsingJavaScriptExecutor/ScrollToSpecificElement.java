package UsingJavaScriptExecutor;

public class ScrollToSpecificElement {

	public static void main(String[] args) {
		
		

	}

}
