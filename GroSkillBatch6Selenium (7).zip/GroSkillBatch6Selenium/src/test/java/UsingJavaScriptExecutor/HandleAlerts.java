package UsingJavaScriptExecutor;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandleAlerts {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		
		JavascriptExecutor js=(JavascriptExecutor)driver;
		
		js.executeScript("alert('Hello Saurabh')", "");
		
		
		

	}

}
