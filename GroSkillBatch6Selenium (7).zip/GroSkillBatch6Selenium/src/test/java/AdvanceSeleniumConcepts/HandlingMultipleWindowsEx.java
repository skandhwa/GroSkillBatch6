package AdvanceSeleniumConcepts;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingMultipleWindowsEx {

	public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();

		driver.get("https://demo.automationtesting.in/Windows.html");

		String parent = driver.getWindowHandle();

		// Open 2 child windows
		driver.findElement(By.cssSelector(".btn.btn-info")).click();
		

		LinkedHashSet<String> handles = (LinkedHashSet<String>) driver.getWindowHandles();

		List<String> windows = new ArrayList<>(handles);

		// Switch to Parent
		driver.switchTo().window(windows.get(0));
		System.out.println(driver.getTitle());

		// Switch to Child 1
		driver.switchTo().window(windows.get(1));
		System.out.println(driver.getTitle());

		// Switch to Child 2
		driver.switchTo().window(windows.get(2));
		System.out.println(driver.getTitle());
		

	}

}
