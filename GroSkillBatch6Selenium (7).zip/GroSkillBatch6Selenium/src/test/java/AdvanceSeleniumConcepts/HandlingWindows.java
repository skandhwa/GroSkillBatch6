package AdvanceSeleniumConcepts;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingWindows {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Windows.html");
		driver.manage().window().maximize();
		
	String WindowId=	driver.getWindowHandle();///A
	
	System.out.println("Window ID is  "+WindowId);
	
	driver.findElement(By.cssSelector("[class='btn btn-info']")).click();
	
	
	Set<String> s1=driver.getWindowHandles();
	
	System.out.println(s1);
	
	String title=driver.getTitle();
	
	System.out.println("Title of page is  "+title);
	
	
	Iterator<String> itr=s1.iterator();
	
	while(itr.hasNext())
	{
		String childWindowID=itr.next();///B
		if(!WindowId.equals(childWindowID))
		{
			driver.switchTo().window(childWindowID);
			System.out.println(driver.getTitle());
			driver.findElement(By.xpath("//*[text()='Downloads']")).click();
		}
		
		
	}
	
	driver.switchTo().window(WindowId);
	System.out.println("Title of page is  "+title);
	
	
		

	}

}
