package MyPractice1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElementCommands7 {

	public static void main(String[] args) throws InterruptedException {
		
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
		
	WebElement ele=	driver.findElement(By.xpath("//input[@id='checkbox1']"));
	
//	boolean flag=ele.isSelected();
//	System.out.println("Is the checkbox selected "+flag);
//	
//	Thread.sleep(3000);
//	driver.navigate().refresh();
	
	Thread.sleep(3000);
	
	boolean flag1=ele.isSelected();
	System.out.println("Is the checkbox selected "+flag1);

	}

}
