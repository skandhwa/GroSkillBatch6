package MyPractice1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class HandlingMultiSelectDropdown {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver =new ChromeDriver();
		driver.get("https://testautomationcentral.com/demo/dropdown.html?utm_source=chatgpt.com");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//*[text()='Multi-Select']")).click();
		Thread.sleep(3000);
	WebElement ele=	driver.findElement(By.xpath("//select[@class='form-multiselect block w-full mt-1']"));
		
	
		Select oselect=new Select(ele);
		if(oselect.isMultiple()==true)
		{
			oselect.selectByIndex(0);
			oselect.selectByIndex(1);
			oselect.selectByIndex(2);
		}
		Thread.sleep(3000);
		//oselect.deselectAll();
		
	WebElement ele1=	oselect.getFirstSelectedOption();
	
	System.out.println(ele1.getText());
	
	    List<WebElement> li=   oselect.getAllSelectedOptions();
		for(WebElement x:li)
		{
			System.out.println(x.getText());
		}
		
		
		
		

	}

}
