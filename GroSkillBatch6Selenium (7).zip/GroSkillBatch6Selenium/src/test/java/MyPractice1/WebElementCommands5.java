package MyPractice1;

import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElementCommands5 {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		driver.manage().window().maximize();
		
	WebElement tagName=	driver.findElement(By.xpath("//input[@type='email876']"));
		
	if(tagName.isDisplayed()==true)
	{
		System.out.println("Element is displayed");
	}
	
	else
	{
		throw new NoSuchElementException("No element present");
	}
	
	

	}

}
