package MyPractice1;

import org.openqa.selenium.By;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElementCommands8 {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
	      driver.get("https://demo.automationtesting.in/Register.html");
	      driver.manage().window().maximize();
	      
	  WebElement ele= driver.findElement(By.xpath("//input[@placeholder='First Name']"));
		
	  Point p=ele.getLocation();
	  
	  System.out.println("Location of element is   "+p.getX()+"  "+p.getY());;
	  
	  
	  

	}

}
