package MyPractice1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElementCommands6 {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://www.w3schools.com/jsref/tryit.asp?filename=tryjsref_pushbutton_disabled2&utm_source=chatgpt.com");
		driver.manage().window().maximize();
		driver.switchTo().frame("iframeResult");
		Thread.sleep(3000);
		WebElement ele=driver.findElement(By.xpath("//button[text()='Try it']"));
		WebElement ele1=driver.findElement(By.xpath("//button[@id='myBtn']"));

		if(ele1.isEnabled()==true)
		{
			System.out.println("Button is enabled");
		}
		
		else
		{
			System.out.println("Button is disabled");
		}
		
		Thread.sleep(3000);
		
		ele.click();
		Thread.sleep(3000);
		
		if(ele1.isEnabled()==true)
		{
			System.out.println("Button is enabled");
		}
		
		else
		{
			System.out.println("Button is disabled");
		}
		
		
		
		
	}

}
