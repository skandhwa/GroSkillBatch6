package MyPractice1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowserCommands2 {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
	String x=	driver.getCurrentUrl();
	
	System.out.println("Current URL is  "+x);
	
	String pageSource=driver.getPageSource();
	
	System.out.println("Page source is  "+pageSource);
	
	
	

	}

}
