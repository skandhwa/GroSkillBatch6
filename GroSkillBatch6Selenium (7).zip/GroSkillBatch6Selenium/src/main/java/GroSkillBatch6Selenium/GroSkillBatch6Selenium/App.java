package GroSkillBatch6Selenium.GroSkillBatch6Selenium;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
