package AdvanceSeleniumConcepts;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingWindows {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Windows.html");
		driver.manage().window().maximize();
		
	String WindowId=	driver.getWindowHandle();
	
	System.out.println("Window ID is  "+WindowId);
	
	driver.findElement(By.cssSelector("[class='btn btn-info']")).click();
	
	
	Set<String> s1=driver.getWindowHandles();
	
	System.out.println(s1);
		

	}

}
