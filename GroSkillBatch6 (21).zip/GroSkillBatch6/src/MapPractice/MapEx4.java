package MapPractice;

import java.util.Map;
import java.util.TreeMap;

public class MapEx4 {

	public static void main(String[] args) {
		
		Map<Integer,String> mp=new TreeMap<Integer,String>();
		mp.put(34,"pat");
		mp.put(67,"tom");
		mp.put(12, "john");
		mp.put(56, "harry");
		
		
		for(Map.Entry x: mp.entrySet())
		{
			System.out.println(x.getKey()+"  "+x.getValue());
		}
		
		
		

	}

}
