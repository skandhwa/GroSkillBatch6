package MapPractice;

import java.util.LinkedHashMap;
import java.util.Map;

public class MapEx1 {

	public static void main(String[] args) {
		
		Map<Integer,String> mp=new LinkedHashMap<Integer,String>();
		mp.put(12,"harry");
		mp.put(34, "sam");
		mp.put(8,"tony");
		mp.put(5, "david");
		mp.put(34, "henry");
		mp.put(65, "harry");
		mp.put(19, "tony");
		
		System.out.println(mp);
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey()+" ");
			System.out.println(x.getValue());
		}
		
		
		
		
		
		
		
		

	}

}
