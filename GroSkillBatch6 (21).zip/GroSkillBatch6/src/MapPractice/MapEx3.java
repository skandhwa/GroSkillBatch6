package MapPractice;

import java.util.LinkedHashMap;
import java.util.Map;

public class MapEx3 {

	public static void main(String[] args) {
		
		Map<Integer,String> mp=new LinkedHashMap<Integer,String>();
		mp.put(12,"harry");
		mp.put(43,"sam");
		mp.put(null,"tony");
		mp.put(98,"john");
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.println(x.getKey() +"  "+x.getValue());
		}
		
		
		
		

	}

}
