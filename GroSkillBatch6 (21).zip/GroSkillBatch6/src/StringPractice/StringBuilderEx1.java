package StringPractice;

public class StringBuilderEx1 {

	public static void main(String[] args) {
		
		
		  String word = "tomorrow";
	        StringBuilder sb = new StringBuilder();

	        int count = 1;

	        for (char ch : word.toCharArray()) 
	        {

	            if (ch == 'o') 
	            {
	                
	                for (int i = 0; i < count; i++) //i=0,0<3//1<3//2<3
	                {
	                    sb.append("@");//
	                }
	                count++;//count=2
	            } 
	            
	            else 
	            {
	                sb.append(ch);
	            }
	        }

	        System.out.println(sb.toString());

	}

}
