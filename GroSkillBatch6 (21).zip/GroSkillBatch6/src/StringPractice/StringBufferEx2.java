package StringPractice;

public class StringBufferEx2 {

	public static void main(String[] args) {
		
		StringBuffer sb=new StringBuffer("I love  tea");
		
		sb.replace(7, 10, "coffee");
		
		System.out.println(sb);
		

	}

}
