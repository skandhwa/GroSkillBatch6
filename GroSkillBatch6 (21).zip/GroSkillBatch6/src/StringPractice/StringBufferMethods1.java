package StringPractice;

public class StringBufferMethods1 {

	public static void main(String[] args) {
		
		StringBuffer sb=new StringBuffer("Java");
		sb.insert(1,'b');
		
		System.out.println(sb);
		

	}

}
