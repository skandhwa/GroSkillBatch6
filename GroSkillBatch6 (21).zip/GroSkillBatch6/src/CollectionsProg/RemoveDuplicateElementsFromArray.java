package CollectionsProg;

import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Set;

public class RemoveDuplicateElementsFromArray {

	public static void main(String[] args) {
		
		int []a= {12,45,67,45,12,99};
		
		Set<Integer> s1=new LinkedHashSet<Integer>();
		
		for(Integer x:a)
		{
			s1.add(x);
		}
		
		System.out.println(s1);
		
		
	Integer[] arr=	s1.toArray(new Integer[0]);
	
	Object[] arr1= s1.toArray();
	
	
	
	
	System.out.println(Arrays.toString(arr1));
		
		
		

	}

}
