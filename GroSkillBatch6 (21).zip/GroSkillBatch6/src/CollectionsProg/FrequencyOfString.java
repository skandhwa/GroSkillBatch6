package CollectionsProg;

import java.util.LinkedHashMap;
import java.util.Map;

public class FrequencyOfString {

	public static void main(String[] args) {
		
		String str="tip tap toe tip tip tap";
		
		String []s1=str.split(" ");
		
		Map<String,Integer> mp=new LinkedHashMap<String,Integer>();
		
			for(String x:s1)
			{
				if(mp.containsKey(x))
				{
					mp.put(x, (mp.get(x)+1));
				}
				
				else
				{
					mp.put(x, 1);
				}
			}
			
			 for (Map.Entry<String, Integer> y : mp.entrySet()) {
		            System.out.println(y.getKey() + " --> " + y.getValue());
		        }
		
			 
			 int maxFreq = 0;
		        int minFreq = Integer.MAX_VALUE;

		        String maxElement = "" ;
		        String minElement = "";

		        // Find max and min frequency character
		        for (Map.Entry<String, Integer> z : mp.entrySet()) {

		            int freq = z.getValue();
		            String element = z.getKey();

		            if (freq > maxFreq) {
		                maxFreq = freq;
		                maxElement = element;
		            }

		            if (freq < minFreq) {
		                minFreq = freq;
		                minElement = element;
		            }
		        }

		        System.out.println("Maximum Frequency is " 
		                + maxElement + " --> " + maxFreq);

		        System.out.println("Minimum Frequency is " 
		                + minElement + " --> " + minFreq);
			 

	}

}
