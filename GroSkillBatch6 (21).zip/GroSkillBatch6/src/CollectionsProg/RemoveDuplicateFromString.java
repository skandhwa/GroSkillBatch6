package CollectionsProg;

import java.util.LinkedHashSet;
import java.util.Set;

public class RemoveDuplicateFromString {

	public static void main(String[] args) {
		
		String str="Saurabh";
		
		char []ch=str.toCharArray();
		
		Set<Character> s1=new LinkedHashSet<Character>();
		
		for(char y:ch)
		{
			s1.add(y);
		}
		
		System.out.println(s1);
		
		
        String result= "";
		
		for(char y:s1)
		{
			result=result+y;
		}
		
		System.out.println(result);
		

	}

}
