package CollectionsProg;

import java.util.LinkedHashSet;
import java.util.Set;

public class PrintDupicateElementsFromArray {

	public static void main(String[] args) {
		
		
		int[]a= {12,45,67,45,88,12,99,77,55};
		
		Set<Integer> s1=new LinkedHashSet<Integer>();
		
		for(int x:a)
		{
			if(!s1.add(x))
			{
				System.out.println(x);
			}
			
			
			
		}
		
		

	}

}
