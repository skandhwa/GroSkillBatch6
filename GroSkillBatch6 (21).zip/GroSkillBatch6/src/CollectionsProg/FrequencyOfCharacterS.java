package CollectionsProg;

import java.util.LinkedHashMap;
import java.util.Map;

public class FrequencyOfCharacterS {

    public static void main(String[] args) {

        String str = "mississippi";

        Map<Character, Integer> mp = new LinkedHashMap<>();

        char[] ch = str.toCharArray();

        // Count frequency
        for (char x : ch) {
            if (mp.containsKey(x)) {
                mp.put(x, mp.get(x) + 1);
            } else {
                mp.put(x, 1);
            }
        }

        // Print frequencies
        for (Map.Entry<Character, Integer> y : mp.entrySet()) {
            System.out.println(y.getKey() + " --> " + y.getValue());
        }

        int maxFreq = 0;
        int minFreq = Integer.MAX_VALUE;

        char maxElement = ' ';
        char minElement = ' ';

        // Find max and min frequency character
        for (Map.Entry<Character, Integer> z : mp.entrySet()) {

            int freq = z.getValue();
            char element = z.getKey();

            if (freq > maxFreq) {
                maxFreq = freq;
                maxElement = element;
            }

            if (freq < minFreq) {
                minFreq = freq;
                minElement = element;
            }
        }

        System.out.println("Maximum Frequency is " 
                + maxElement + " --> " + maxFreq);

        System.out.println("Minimum Frequency is " 
                + minElement + " --> " + minFreq);
    }
}