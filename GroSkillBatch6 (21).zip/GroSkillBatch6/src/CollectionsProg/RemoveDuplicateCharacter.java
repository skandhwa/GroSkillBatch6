package CollectionsProg;

import java.util.LinkedHashSet;
import java.util.Set;

public class RemoveDuplicateCharacter {

	public static void main(String[] args) {
		
		String str="Saurabh";
		
		Set<Character> s1=new LinkedHashSet<Character>();
		
		for(int i=0;i<str.length();i++)
		{
			s1.add(str.charAt(i));
		}
		
		String result= "";
		
		for(char y:s1)
		{
			result=result+y;
		}
		
		System.out.println(result);
		

	}

}
