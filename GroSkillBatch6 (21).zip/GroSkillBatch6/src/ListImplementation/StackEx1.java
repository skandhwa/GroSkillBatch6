package ListImplementation;

import java.util.Stack;

public class StackEx1 {

	public static void main(String[] args) {
		
		
		Stack<Integer> stk=new Stack<Integer>();
		stk.push(23);
		stk.push(55);
		stk.push(89);
		
		stk.pop();
		
		System.out.println(stk);
		
		
		

	}

}
