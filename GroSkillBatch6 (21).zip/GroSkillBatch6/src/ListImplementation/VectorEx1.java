package ListImplementation;

import java.util.Collections;
import java.util.Vector;

public class VectorEx1 {

	public static void main(String[] args) {
		
		Vector<Integer> v=new Vector<Integer>();
		v.add(23);
		v.add(56);
		v.add(89);
		
		for(Integer x:v)
		{
			System.out.println(x);
		}
		
		Collections.sort(v);

	}

}
