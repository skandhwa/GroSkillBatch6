package ListImplementation;

import java.util.ArrayList;
import java.util.List;

public class ListMethods1 {

	public static void main(String[] args) {
		
		List<String>li=new ArrayList<String>();
		li.add("mango");
		li.add("guava");
		li.add("apple");
		li.add("papaya");
		
		
		Object[]arr=li.toArray();
		
	int x=	li.size();
	System.out.println("Size of list is  "+x);
	
	String y=li.get(2);
	System.out.println("Element at second index is "+y);
	
	boolean flag=li.contains("guava");
	System.out.println("Does the list contains guava "+flag);
	
	li.remove(3);
	System.out.println(li);
	
	li.remove("mango");
	System.out.println(li);
	
	
	
	
	
	
		
		

//		
//		List<String>li2=new ArrayList<String>();
//		li2.add("orange");
//		li2.add("lemon");
//		li2.add("kiwi");
//		li2.add("papaya");	
//		
		
		
		
	}

}
