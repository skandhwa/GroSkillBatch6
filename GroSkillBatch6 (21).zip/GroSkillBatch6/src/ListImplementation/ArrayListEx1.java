package ListImplementation;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ArrayListEx1 {

	public static void main(String[] args) {
		
		
		List<Integer> li=new ArrayList<Integer>();
		li.add(23);
		li.add(67);
		li.add(11);
		li.add(22);
		
		for(Integer x:li)
		{
			System.out.println(x);
		}
		System.out.println("##############################################");
		
		for(int i=0;i<li.size();i++)
		{
			System.out.println(li.get(i));
		}
		
		System.out.println("##############################################");
		
		
		Iterator itr=li.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		
		Iterator<Integer> itr1 = li.iterator();

		while (itr1.hasNext()) 
		{
		    Integer y = itr1.next();

		    if (y == 11) {
		        System.out.println("Found 11");
		    }
		    
		    if(y==67)
		    {
		    	itr1.remove();
		    }
		    
		    System.out.println(li);
		    
		}
		
		
		

	}

}
