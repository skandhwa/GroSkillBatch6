package ListImplementation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MoveAllZerosToOneSide {

	public static void main(String[] args) {
		
		
		int []a= {-1,4,3,-2,0,5,0,0};
		
		List<Integer> li1=new ArrayList<Integer>();
		List<Integer> li2=new ArrayList<Integer>();
		
		
		for(int x:a)
		{
			if(x!=0)
			{
				li1.add(x);
				Collections.sort(li1);
				Collections.reverse(li1);
				
			}
			else
			{
				li2.add(x);
				
				
			}
			
		}
		
		
		li1.addAll(li2);
		
		for(Integer y:li1)
		{
			System.out.print(y+" ");
		}
		

	}

}
