package ListImplementation;

import java.util.PriorityQueue;
import java.util.Queue;

public class QueueEx1 {

	public static void main(String[] args) {
		
		Queue<Integer> q1=new PriorityQueue<Integer>();
		
		q1.add(55);
		q1.add(60);
		q1.add(90);
		q1.add(105);
		
		for(Integer x:q1)
		{
			System.out.println(x);
		}
		
		q1.remove();
		
		System.out.println("After removal");
		
		for(Integer x:q1)
		{
			System.out.println(x);
		}
		

	}

}
