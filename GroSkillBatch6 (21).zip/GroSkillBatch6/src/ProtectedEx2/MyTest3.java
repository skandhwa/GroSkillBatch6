package ProtectedEx2;

import ProtectedEx1.MyTest1;

public class MyTest3 extends MyTest1  {

	public static void main(String[] args) {
		  
		
		MyTest3 obj=new MyTest3();
		System.out.println(obj.x);
		obj.display();
		
//		MyTest1 oj=new MyTest1();
//		System.out.println(oj.x);
//		oj.display();
		

	}

}
