package PrivatePractice1;

class A1
{
	private void display()
	{
		System.out.println("Hello");
	}
	
}

class A2 extends A1
{
	private void display()
	{
		System.out.println("Hello");
	}
}




public class PrivateEx2 {

	public static void main(String[] args) 
	{
		A1 obj=new A1();
		obj.

	}

}
