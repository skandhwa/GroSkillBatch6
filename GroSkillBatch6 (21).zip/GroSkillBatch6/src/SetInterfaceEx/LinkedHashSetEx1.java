package SetInterfaceEx;

import java.util.LinkedHashSet;
import java.util.Set;

public class LinkedHashSetEx1 {

	public static void main(String[] args) {
		
		Set<Object>s1=new LinkedHashSet<Object>();
		s1.add(45);
		s1.add("apple");
		s1.add(true);
		s1.add('A');
		s1.add(45);
		s1.add(null);
		
		for(Object x:s1)
		{
			System.out.println(x);
		}
		

	}

}
