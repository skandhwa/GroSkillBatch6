package DefaultPractice1;


public class MyDefaultEx1 {
	  int x=10;
	    void display()
		{
			System.out.println("Hello");
		}

	public static void main(String[] args) {
		
		MyDefaultEx1 obj=new MyDefaultEx1();
		obj.display();
		
	System.out.println(obj.x);	
	
		
		

	}

}
