package InterfacePractice;

interface I20
{
	static void test()
	{
		System.out.println("Hello");
	}
}



public class InterfaceEx8 {

	public static void main(String[] args) {
		
		I20.test();
		

	}

}
