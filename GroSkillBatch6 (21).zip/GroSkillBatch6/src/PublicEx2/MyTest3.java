package PublicEx2;

import PublicEx1.MyTest1;

public class MyTest3 extends MyTest1 {

	public static void main(String[] args) {
		
		
		MyTest1 obj=new MyTest1();
		obj.display();
		
		MyTest3 obj1=new MyTest3();
		obj1.display();

	}

}
