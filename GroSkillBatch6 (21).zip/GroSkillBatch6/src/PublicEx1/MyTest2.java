package PublicEx1;

public class MyTest2 {

	public static void main(String[] args) {
		
		MyTest1 obj=new MyTest1();
		obj.display();

	}

}
