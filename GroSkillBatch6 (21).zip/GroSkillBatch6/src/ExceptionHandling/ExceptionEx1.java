package ExceptionHandling;

public class ExceptionEx1 {

	public static void main(String[] args) {
		
		try
		{
		
		int x=9/0;
		System.out.println(x);
		
		}
		
		catch(ArithmeticException e)
		{
			System.out.println("caught with  "+e.getMessage());
		}
		
		
		
		int a=20,b=30,c=40;
		int res=a+b+c;
		System.out.println(res);
		

	}

}
