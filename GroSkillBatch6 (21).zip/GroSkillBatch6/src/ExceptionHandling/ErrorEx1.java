package ExceptionHandling;

public class ErrorEx1 {

	public static void main(String[] args) {
		
		main(args);
		

	}

}
