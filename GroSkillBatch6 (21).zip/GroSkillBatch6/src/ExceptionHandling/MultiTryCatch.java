package ExceptionHandling;

public class MultiTryCatch {

	public static void main(String[] args) {
		
		try
		{
		int x=9/3;
		System.out.println(x);
		
		
		String str=null;
		int y=str.length();
		System.out.println("Length of String is  "+y);
		
		
		
       int []arr= {34,67,89,12,56};
       System.out.println(arr[6]);
       
		}
		
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("caught with "+e.getMessage());
		}
		catch(ArithmeticException e)
		{
			System.out.println("caught with "+e.getMessage());
		}
		
		
		
		catch(NullPointerException e)
		{
			System.out.println("caught with "+e.getMessage());
		}
		
		
		int a=20,b=30,c=40;
		int res=a+b+c;
		System.out.println(res);
		
		

	}

}
