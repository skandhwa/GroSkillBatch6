package ExceptionHandling;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ThrowsKeyWordEx {

	public static void main(String[] args) throws IOException, InterruptedException
	{
		
		System.out.println("Hello");
		
		Thread.sleep(5000);
		
		FileReader file = new FileReader("test.txt");
		
		 FileReader f = new FileReader("sample.txt");
         BufferedReader reader = new BufferedReader(f);
         System.out.println(reader.readLine());
		
		
		
		

	}

}
