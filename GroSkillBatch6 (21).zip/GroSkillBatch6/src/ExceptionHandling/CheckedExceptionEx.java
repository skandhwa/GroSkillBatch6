package ExceptionHandling;

import java.io.File;
import java.io.FileNotFoundException;

class D10
{
	public static void checkFile(String path) throws FileNotFoundException
	{
		File f=new File(path);
		if(!f.exists())
		{
			throw new FileNotFoundException("File not found  "+path);
		}
		
		else
		{
			System.out.println("File found");
		}
		
		
	}
}



public class CheckedExceptionEx {

	public static void main(String[] args) throws FileNotFoundException {
		
		D10.checkFile("D:/Conditional Statementrtf.txt");
		
		
		

	}

}
