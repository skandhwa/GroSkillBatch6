package ProtectedEx1;

public class MyTest2 {

	public static void main(String[] args) {
		
		MyTest1 oj=new MyTest1();
		System.out.println(oj.x);
		oj.display();

	}

}
