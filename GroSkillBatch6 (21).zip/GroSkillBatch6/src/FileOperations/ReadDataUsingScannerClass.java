package FileOperations;

import java.io.File;
import java.util.Scanner;

public class ReadDataUsingScannerClass {

	public static void main(String[] args) {
		
		File f=new File("D:/TestDataFolder17thOct/MyTest3.txt");
		Scanner sc=new Scanner(System.in);
		while(sc.hasNextLine())
		{
			System.out.println(sc.nextLine());
		}
		
		sc.close();

	}
	
	
	//  D:\\TestDataFolder17thOct\\MyTest.txt

}
