package FileOperations;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class ReadDataFromFile {

	public static void main(String[] args) throws IOException {
		
		BufferedReader br = new BufferedReader(
		        new FileReader("D:/TestDataFolder17thOct/MyTest.txt"));

		String line;
		String searchWord = "Python";
		boolean found = false;
		int lineNumber = 1;

		while ((line = br.readLine()) != null) {

		    // Print each line
		    System.out.println(line);

		    // Search word
		    if (line.contains(searchWord)) {
		        found = true;
		        System.out.println("Word found at line " + lineNumber);
		        System.out.println("Line: " + line);
		    }

		    lineNumber++;
		}

		if (!found) {
		    System.out.println("Word not found.");
		}

		br.close();
	
	

}
}
