package MyPractice1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElementCommands1 {

	public static void main(String[] args) {

      WebDriver driver=new ChromeDriver();
      driver.get("https://demo.automationtesting.in/Register.html");
      driver.manage().window().maximize();
      
  WebElement ele= driver.findElement(By.xpath("//input[@placeholder='First Name']"));
   ele.sendKeys("Harry");
   
 List<WebElement> li=  driver.findElements(By.tagName("aytf"));
   
   int x=li.size();
   
   System.out.println("Total number of links present in page are  "+x);
  
  

	}

}
