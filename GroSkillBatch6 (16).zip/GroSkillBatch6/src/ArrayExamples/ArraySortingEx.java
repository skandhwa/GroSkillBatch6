package ArrayExamples;

public class ArraySortingEx {

	public static void main(String[] args) {
		
//		int []a= {12,56,3,9,34};
//		
//		for(int i=0;i<a.length;i++)
//		{
//			for(int j=i+1;j<a.length;j++)//j=5
//			{
//				if(a[i]>a[j])///
//				{
//					int temp=a[i];
//					a[i]=a[j];
//					a[j]=temp;
//					
//				}
//			}
//		}
//		
//		for(int x:a)
//		{
//			System.out.print(x+" ");
//		}
		
		
int []a= {12,56,3,9,34};
		
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)//j=5
			{
				if(a[i]<a[j])///
				{
					int temp=a[i];
					a[i]=a[j];
					a[j]=temp;
					
				}
			}
		}
		
		for(int x:a)
		{
			System.out.print(x+" ");
		}
		
		
		
		

	}

}
