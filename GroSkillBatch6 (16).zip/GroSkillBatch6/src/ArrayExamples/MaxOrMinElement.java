package ArrayExamples;

import java.util.Scanner;

class MaxMin
{
	public static int minMax(int []a,int n)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter which ,minimum or max element u want \n");
		int x=sc.nextInt();
		
		
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i]>a[j])///
				{
					int temp=a[i];
					a[i]=a[j];
					a[j]=temp;
					
				}
			}
		}
		
		return a[n-x];
	}
}




public class MaxOrMinElement {

	public static void main(String[] args) {
		
		int []a= {12,56,3,9,34};
		int n=a.length;
		
	System.out.println(MaxMin.minMax(a,n));	
		

	}

}
