package ArrayExamples;

public class ArrayEvenPos {

	public static void main(String[] args) {
		
		int []a= {12,-145,67,88};
		
		for(int i=2;i<=a.length-1;i=i+3)//i=0,0<5//i=1,1<5
		{
			
			System.out.println(a[i]);//a[0]//a[1]
		}

	}

}
