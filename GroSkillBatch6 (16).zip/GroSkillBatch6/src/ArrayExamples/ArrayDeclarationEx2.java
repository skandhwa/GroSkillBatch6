package ArrayExamples;

public class ArrayDeclarationEx2 {

	public static void main(String[] args) {
		
		int []b=new int[] {56,78,99,102,34};
		
		for(int x:b)
		{
			System.out.println(x);
		}
		
		
		
		
		
		
		

	}

}
