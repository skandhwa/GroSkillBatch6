package ArrayExamples;

public class MultiDimnsionalArrayEx {

	public static void main(String[] args) {
		
		int [][]a=new int[][] {{1,3,5},{2,4,6},{7,9,0}};
		
		for(int i=0;i<a.length;i++)///i=0,0<3
		{
			for(int j=0;j<a.length;j++)//j=0,0<3//j=1,1<3//j=2,2<3
			{
				System.out.print(a[i][j]+" ");
				
				//a[0][0]//a[0][1]//a[0][2]
			}
			
			System.out.println();
		}
		
		
		

	}

}
