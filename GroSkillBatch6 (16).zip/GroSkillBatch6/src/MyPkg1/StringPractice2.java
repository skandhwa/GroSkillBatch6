package MyPkg1;

public class StringPractice2 {

	public static void main(String[] args) {
		
		String str="India";
		
		int x=str.length();
		
		System.out.println("Length of string is  "+x);
		
		
		
		

	}

}
