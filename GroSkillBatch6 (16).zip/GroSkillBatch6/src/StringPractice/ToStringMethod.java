package StringPractice;

import java.util.Arrays;

public class ToStringMethod {

	public static void main(String[] args) {
		
		
		int x=20;
		
		Integer y=x;
		
		
		String s1=y.toString();
		
		System.out.println(s1);
		
		
		int []a= {23,45,66,9,8};
		
	String s3=	Arrays.toString(a);
		
		
		
		System.out.println(s3);
		
		
		

	}

}
