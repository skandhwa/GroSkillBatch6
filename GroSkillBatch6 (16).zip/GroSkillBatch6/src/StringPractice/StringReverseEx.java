package StringPractice;

public class StringReverseEx {

	public static void main(String[] args) {
		
		String str="madam";
		
		String str1=str;
		
		String revstr="";
		
		for(int i=str.length()-1;i>=0;i--)//i=4-1=3,3>=0//i=2,2>=0//i=1,1>=0//0>=0
		{
			revstr=revstr+str.charAt(i);///revstr=""+n=n//revstr=n+h=nh//revstr=nh+o=nho//revstr=nho+j=nhoj
		}
		
		System.out.println(revstr);
		
		if(str1.equals(revstr))
		{
			System.out.println("String is palindrome");
		}
		
		else{
			
			System.out.println("String is not palindrome");
		}
		

	}

}
