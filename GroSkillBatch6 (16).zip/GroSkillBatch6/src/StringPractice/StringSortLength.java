package StringPractice;

public class StringSortLength {

	public static void main(String[] args) {
		
		String str="Java is a programming language" ;
		
	String []s1=	str.split(" ");
	
	for(int i=0;i<s1.length;i++)//i=0,0<5
	{
		for(int j=i+1;j<s1.length;j++)//j=1,1<5//j=2,2<5
		{
			if(s1[i].length()>s1[j].length())///
			{
				String t=s1[i];
				s1[i]=s1[j];
				s1[j]=t;
			}
		}
	}
	
	
	for(int i=0;i<s1.length;i++)
	{
		System.out.print(s1[i]+" ");
	}
		

	}

}
