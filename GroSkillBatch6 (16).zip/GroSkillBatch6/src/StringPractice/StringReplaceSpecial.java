package StringPractice;

public class StringReplaceSpecial {

	public static void main(String[] args) {
		
		String str="abcd@#$%1234ABCD";
		
		str=str.replaceAll("[^a-zA-Z0-9]", "");
		
		System.out.println(str);
		

	}

}
