package StringPractice;

public class StringMethods9 {

	public static void main(String[] args) {
		
		String str="India  ";
		
		char []s1= str.toCharArray();
		
		for(char x:s1)
		{
			System.out.println(x);
		}
		

	}

}
