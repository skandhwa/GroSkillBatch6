package StringPractice;

public class STringMethods11 {

	public static void main(String[] args) {
		
		
		String str="Harry";
		
		String str1="harry";
		
	boolean flag=	str.equalsIgnoreCase(str1);
	
	System.out.println(flag);

	}

}
