package StringPractice;

public class StringMethods6 {

	public static void main(String[] args) {
		
		String str="Harry Brooka Williams";
		
		int x=str.indexOf('a',-1);
		
		System.out.println("Index of a is  "+x);
		

	}

}
