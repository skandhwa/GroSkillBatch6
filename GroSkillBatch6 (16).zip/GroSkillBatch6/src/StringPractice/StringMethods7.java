package StringPractice;

public class StringMethods7 {

	public static void main(String[] args) {
		
		String str="Bharat Republic Bharat Bharat";
		
//		str=str.replace('c', 'a');
//		
//		System.out.println(str);
		
//	str=	str.replaceAll("Bharat", "India");
//	
//	System.out.println(str);
		
	str=	str.replaceFirst("Bharat", "India");
	
	System.out.println(str);
		
	

		
		
//		
		
		
		

	}

}
