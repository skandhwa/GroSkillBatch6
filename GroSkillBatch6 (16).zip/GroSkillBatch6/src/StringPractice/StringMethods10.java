package StringPractice;

public class StringMethods10 {

	public static void main(String[] args) {
		
		String str="aBcde";
		
	str=	str.toUpperCase();
	
	System.out.println(str);
		

	}

}
