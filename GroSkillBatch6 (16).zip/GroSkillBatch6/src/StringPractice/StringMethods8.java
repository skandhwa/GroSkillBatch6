package StringPractice;

public class StringMethods8 {

	public static void main(String[] args) {
		
//		String str="java@@language@selenium";
//		
//		String []s=str.split("@");
//		
//		//System.out.println(s[2]);
//		
//		
//		for(String a:s)
//		{
//			System.out.println(a);
//		}
		
		
		String str="Indian Nation";
		
	String []s1=	str.split("N");
	
	for(String a:s1)
	{
		System.out.println(a);
		}
		
		
		

	}

}
