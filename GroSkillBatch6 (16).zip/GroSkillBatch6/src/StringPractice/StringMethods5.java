package StringPractice;

public class StringMethods5 {

	public static void main(String[] args) {
		
		String str1=""
		

	}

}
