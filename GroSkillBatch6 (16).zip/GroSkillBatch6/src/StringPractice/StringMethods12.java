package StringPractice;

public class StringMethods12 {

	public static void main(String[] args) {
		
		String str2="Java Hello";
		
		String str1="Java Selenium";
		
	int x=	str1.compareTo(str2);
	
	System.out.println(x);
		
	}

}
