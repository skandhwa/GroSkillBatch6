import { test, expect } from '@playwright/test';

test('Keyboard operations on Register page', async ({ page }) => {

  // Open the Registration page
  await page.goto('https://demo.automationtesting.in/Register.html');

  // -------------------------------
  // 1. First Name
  // -------------------------------
  await page.locator('input[placeholder="First Name"]').click();
  await page.keyboard.type('Saurabh');

  // Select all text
  await page.keyboard.press('Control+A');

  // Replace selected text
  await page.keyboard.type('Saurabh Kumar');

  // -------------------------------
  // 2. Move to Last Name using TAB
  // -------------------------------
  await page.keyboard.press('Tab');
  await page.keyboard.type('Test');

  // -------------------------------
  // 3. Move to Address using TAB
  // -------------------------------
  await page.keyboard.press('Tab');
  await page.keyboard.type('Hyderabad, Telangana');

  // -------------------------------
  // 4. Move to Email using TAB
  // -------------------------------
  await page.keyboard.press('Tab');
  await page.keyboard.type('saurabh' + Date.now() + '@gmail.com');

  // -------------------------------
  // 5. Move to Phone using TAB
  // -------------------------------
  await page.keyboard.press('Tab');
  await page.keyboard.type('9876543210');

  // -------------------------------
  // 6. Gender – move using TAB
  // -------------------------------
  await page.keyboard.press('Tab');

  // Select Male radio button using Space
  await page.keyboard.press('Space');

  // -------------------------------
  // 7. Hobbies
  // -------------------------------
  await page.keyboard.press('Tab');

  // Select Cricket checkbox
  await page.keyboard.press('Space');

  // Move to next hobby
  await page.keyboard.press('Tab');

  // Select Movies
  await page.keyboard.press('Space');

  // -------------------------------
  // 8. Demonstrate SHIFT + TAB
  // -------------------------------

  // Move backward to previous element
  await page.keyboard.press('Shift+Tab');

  // -------------------------------
  // 9. Demonstrate BACKSPACE
  // -------------------------------
  await page.keyboard.press('Backspace');

  // -------------------------------
  // 10. Demonstrate ESC
  // -------------------------------
  await page.keyboard.press('Escape');

  console.log('Keyboard operations completed successfully');
});