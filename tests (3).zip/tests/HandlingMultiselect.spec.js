import { test, expect } from '@playwright/test';

test('Handling Multi Select Dropdown', async ({ page }) => {

    // Open real-time website
    await page.goto(
        'https://www.techlistic.com/p/selenium-practice-form.html'
    );

    // Locate the multi-select dropdown
    const multiSelect = page.locator('#selenium_commands');

    // Verify that the dropdown exists
    await expect(multiSelect).toBeVisible();

    // Select first option
    await multiSelect.selectOption({ index: 0 });

    // Select third option
    await multiSelect.selectOption({ index: 2 });

    // Select fourth option
    await multiSelect.selectOption({ index: 3 });

    // Verify selected values
    console.log(
        'Selected values:',
        await multiSelect.inputValue()
    );

    // Wait so you can see the selection
    await page.waitForTimeout(3000);

    // Unselect the third option
    await multiSelect.unselectOption({ index: 2 });

    // Verify remaining selections
    console.log(
        'After unselect:',
        await multiSelect.inputValue()
    );

    await page.waitForTimeout(3000);
});