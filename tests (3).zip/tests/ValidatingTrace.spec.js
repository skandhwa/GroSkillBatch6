import { test, expect } from '@playwright/test';

test('My First Playwright Test @smoke1', async ({ page })=>
{
    
   await page.goto("https://www.google.com/");
   let title1= await page.title();
    console.log(title1);
   
})
