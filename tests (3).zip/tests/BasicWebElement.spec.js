import { test, expect } from '@playwright/test';

test.only('My First Playwright Test @smoke', async ({ page })=>
{
    
   await page.goto("https://demo.automationtesting.in/Register.html");
   let title1= await page.title();
    console.log(title1);
    expect (page).toHaveTitle("Register");
    await page.getByPlaceholder("First Name").fill("Saurabh")
    await page.getByPlaceholder("Last Name").fill("K")

    await page.waitForTimeout(2000);
     await page.getByRole('radio', { name: 'Male', exact: true }).check();
    // await page.getByRole('checkbox',{name:'Cricket'}).check();    

   const dropDown= await page.locator("[id='Skills']");
//const val= await page.locator("[id='Skills']").allTextContents();

   //console.log(val)

  // await dropDown.selectOption("Android");
   await dropDown.selectOption({index:7});
//    await dropDown.selectOption({label:'Configuration'});


    

})
