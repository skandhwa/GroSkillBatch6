import { test, expect } from '@playwright/test';

test('Handling Multi Frames', async ({ page })=>
{

   await page.goto("https://demo.automationtesting.in/Frames.html");
    //await page.locator("a[href='#Multiple']").click();

    await page.click("a[href='#Multiple']");
    await page.waitForTimeout(3000);
   const parentFrame= await page.frameLocator("iframe[src='MultipleFrames.html']");
   await page.waitForTimeout(3000);
  const childFrame= parentFrame.frameLocator("iframe[src='SingleFrame.html']");
  await childFrame.locator("input[type='text']").fill("Saurabh");

  await page.waitForTimeout(4000);

    
})