
import { test, expect } from '@playwright/test';
test('My Second Playwright Test', async ({ page })=>
{

  await page.goto("https://demo.automationtesting.in/Frames.html")
    const frame1= await page.frameLocator("#singleframe");
   await page.waitForTimeout(3000)
   await frame1.locator("input[type='text']").fill("Saurabh")
   
    
})
