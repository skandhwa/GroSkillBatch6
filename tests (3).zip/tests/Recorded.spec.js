import { test, expect } from '@playwright/test';

test('test', async ({ page }) => {
  await page.goto('https://www.google.com/');
  await page.locator('div').filter({ hasText: 'BTS meets Google Gemini.' }).nth(1).click();
  await page.getByRole('combobox', { name: 'Search' }).click();
  await page.getByRole('combobox', { name: 'Search' }).fill('Selenium Java');
  await page.locator('iframe[name="a-91507s6f4cr8"]').contentFrame().getByRole('checkbox', { name: 'I\'m not a robot' }).click();
  await page1.goto('https://www.amazon.com/');
  await page1.getByRole('searchbox', { name: 'Search Amazon' }).click();
  await page1.getByRole('searchbox', { name: 'Search Amazon' }).fill('Mobiel ');
  await page1.goto('https://www.amazon.com/s?k=mobile+phones&crid=31QSD6Z0MN5EP&sprefix=Mobiel+%2Caps%2C507&ref=nb_sb_ss_p13n-expert-pd-ops-ranker_2_7');
  await page1.getByRole('link', { name: 'Samsung Galaxy S26, Unlocked' }).click();
  await page1.goto('https://www.amazon.com/Samsung-Unlocked-Smartphone-Processor-Immersive/dp/B0G4SXD3TJ/ref=sr_1_1?crid=31QSD6Z0MN5EP&dib=eyJ2IjoiMSJ9.isMteTd5L9Bm2gC3UK4jx4xFCA9fycDLRGEuaW-lYsMRiaEHx_S--H0eVCnS1V7gRh8vH7BuZBEPYaKRJyfH7ZFqVQn-fEZObQAHnwWFXMenTAkN_bdpDZQ-E76Ar6vB6UYsgyqSKkPA4u2BjaPAs4JwiI7yvUKXpNYWenoNoBtjMIvCKWSvEjSilK863akqNqo1xIdbfHg7DzMn4VS-PByU2WpUrXchOFmkoLmm6Ks.4G-eSfhtxy08ACA6HSOXHHDcNoYhimHakDU8inpTOT8&dib_tag=se&keywords=mobile+phones&qid=1787588282&sprefix=Mobiel+%2Caps%2C507&sr=8-1');
  await page1.locator('html').click();
  await expect(page1.locator('.a-section.dp-title-differentiators')).toBeVisible();
  await page1.goto('https://www.amazon.com/Samsung-Unlocked-Smartphone-Processor-Immersive/dp/B0G4SXD3TJ/ref=sr_1_1?crid=31QSD6Z0MN5EP&dib=eyJ2IjoiMSJ9.isMteTd5L9Bm2gC3UK4jx4xFCA9fycDLRGEuaW-lYsMRiaEHx_S--H0eVCnS1V7gRh8vH7BuZBEPYaKRJyfH7ZFqVQn-fEZObQAHnwWFXMenTAkN_bdpDZQ-E76Ar6vB6UYsgyqSKkPA4u2BjaPAs4JwiI7yvUKXpNYWenoNoBtjMIvCKWSvEjSilK863akqNqo1xIdbfHg7DzMn4VS-PByU2WpUrXchOFmkoLmm6Ks.4G-eSfhtxy08ACA6HSOXHHDcNoYhimHakDU8inpTOT8&dib_tag=se&keywords=mobile%2Bphones&qid=1787588282&sprefix=Mobiel%2B%2Caps%2C507&sr=8-1&th=1');
  await expect(page1.locator('#title')).toContainText('Samsung Galaxy S26, Unlocked Android Smartphone, 256GB, Cobalt Violet');
});