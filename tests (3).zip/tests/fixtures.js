import { test as base, expect } from '@playwright/test';

// Create custom fixture
export const test = base.extend({

  loggedInPage: 
  
  async ({ page }, use) => {

    // Open Guru99 Bank
    await page.goto('https://demo.guru99.com/V4/index.php');

    // Login
    await page.locator('input[name="uid"]').fill('mngr665644');
    await page.locator('input[name="password"]').fill('vetugus');

    await page.locator('input[name="btnLogin"]').click();

    // Wait for manager page
    await page.waitForLoadState('domcontentloaded');

    // Give the logged-in page to the test
    await use(page);
  }
});

export {expect};