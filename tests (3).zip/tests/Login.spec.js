import { test, expect } from './fixtures.js';

test('Verify Manager Dashboard', async ({ loggedInPage }) => {

  // We don't need to write login code here.
  // Fixture has already logged in.

  await expect(loggedInPage).toHaveTitle('Guru99 Bank Manager HomePage');

  

  await expect(
    loggedInPage.getByText("Welcome To Manager's Page of Guru99 Bank")
  ).toBeVisible();
});


test('Verify Manager ID', async ({ loggedInPage }) => {

  // Again, page is already logged in

  await expect(
    loggedInPage.locator('body')
  ).toContainText('Manager Id');
});