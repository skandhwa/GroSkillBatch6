import { test, expect } from '@playwright/test';


test('Valid Login @smoke @login', async ({ page }) => {
   
      await page.goto('https://google.com');

});

test('Invalid Login @regression @login', async ({ page }) => {
    
  await page.goto('https://amazon.com');

});

test('Search Product @regression @search', async ({ page }) => {
    
  await page.goto('https://flipkart.com');

});