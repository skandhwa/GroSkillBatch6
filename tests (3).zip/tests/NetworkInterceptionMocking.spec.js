import { test } from '@playwright/test';

test('Network Interception and Mocking', async ({ page }) => {

    // Intercept the Register page request
    await page.route(
        'https://demo.automationtesting.in/Register.html',
        async (route) => {

            console.log('----------------------------------');
            console.log('Network Request Intercepted');
            console.log('URL:', route.request().url());

            // Fake response
            const fakeResponse = `
                <html>
                    <head>
                        <title>Mocked Registration Page</title>
                    </head>
                    <body>
                        <h1>Fake Registration Page</h1>
                        <p>Name: Test User</p>
                        <p>Email: testuser@gmail.com</p>
                        <p>Status: Registration Successful</p>
                    </body>
                </html>
            `;

            // Print fake response in console
            console.log('Fake Response:');
            console.log(fakeResponse);

            // Send fake response to browser
            await route.abort({
                status: 200,
                contentType: 'text/html',
                body: fakeResponse
            });

            console.log('Fake response sent to browser');
            console.log('----------------------------------');
        }
    );

    // User tries to open the real website
    await page.goto(
        'https://demo.automationtesting.in/Register.html'
    );

    // Print browser content
    console.log('Page Content:');
    console.log(await page.locator('body').innerText());
});