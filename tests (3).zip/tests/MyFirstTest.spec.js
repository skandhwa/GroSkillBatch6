import { test, expect } from '@playwright/test';

test('My First Playwright Test @smoke', async ({ page })=>
{
    
   await page.goto("https://www.google.com/");
   let title1= await page.title();
    console.log(title1);
    expect (page).toHaveTitle("Google1");
})


test('My Second Playwright Test', async ({ page })=>
{

   await page.goto("https://www.amazon.com/");
    await page.title();
    test.slow("This is a slow test")
    
})

test('My third Playwright Test', async ({ page })=>
{

   await page.goto("https://www.flipkart.com/");
    let title=await page.title();
    console.log(title);
    
})

