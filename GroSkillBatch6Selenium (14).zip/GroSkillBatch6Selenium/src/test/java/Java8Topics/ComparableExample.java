package Java8Topics;

import java.util.ArrayList;
import java.util.Collections;

class Student implements Comparable<Student>
{
	private String name;
	private int age;
	private double salary;
	
	
	
	public String getName() {
		return name;
	}

	public double getSalary() {
		return salary;
	}

	public int getAge() {
		return age;
	}

	
	public Student(String name,int age,double salary)
	{
		this.name=name;
		this.age=age;
		this.salary=salary;
		
	}
	
//	public int compareTo(Student st)
//	{
//		return this.name.compareTo(st.name);
//	}
	
//	public int compareTo(Student st)
//	{
//		return Double.compare(this.salary, st.salary);
//	}
	

	public int compareTo(Student st) 
	{
		return this.age-st.age;
	}
	
	
	
	
}

public class ComparableExample {

	public static void main(String[] args) {
		
		
		ArrayList<Student> li=new ArrayList<>();
		li.add(new Student("Saurabh",33,80000));
		li.add(new Student("Gaurabh",54,90000));
		li.add(new Student("Manish",22,70000));
		
		Collections.sort(li);
		
		for(Student x:li)
		{
			System.out.println(x.getName()+"  "+x.getAge()+"  "+x.getSalary());
		}
		
		
		

	}

}
