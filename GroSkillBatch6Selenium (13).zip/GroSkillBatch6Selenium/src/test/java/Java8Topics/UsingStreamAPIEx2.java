package Java8Topics;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class UsingStreamAPIEx2 {

	public static void main(String[] args) {
		
		List<String> li=new ArrayList<String>();
		li.add("India");
		li.add("Nepal");
		li.add("USA");
		li.add("Indonesia");
		li.add("Netherland");
		li.add("Norway");
		li.add("China");
		li.add("India");
		li.add("USA");
		
		Stream<String> st=li.stream();
		
		
		List<String> li2 = st
		        .map(s -> s.toLowerCase())
		        .collect(Collectors.toList());

		System.out.println(li2);
		
		System.out.println("#######################################");
		
		List<String> li3 = li.stream()
		        .sorted()
		        .collect(Collectors.toList());

		System.out.println(li3);
		System.out.println("#######################################");
		
		List<String> li4 = li.stream()
		        .sorted((a, b) -> b.compareTo(a)) // reverse order
		        .collect(Collectors.toList());
		System.out.println(li4);

		System.out.println("#######################################");
			li.stream()
		  .forEach(s -> System.out.println(s));
			
			System.out.println("#######################################");	
			List<String> li5 = li.stream()
			        .limit(3)
			        .collect(Collectors.toList());

			System.out.println(li5);
			
			System.out.println("#######################################");		
			List<String> li6 = li.stream()
			        .skip(2)
			        .collect(Collectors.toList());

			System.out.println(li6);
			System.out.println("#######################################");	
			
			List<String> li7 = li.stream()
			        .distinct()
			        .collect(Collectors.toList());

			System.out.println(li7);
			
			System.out.println("#######################################");	

			long count = li.stream()
			        .filter(s -> s.startsWith("N"))
			        .count();

			System.out.println(count);
           
			System.out.println("#######################################");
			
			boolean result = li.stream()
			        .anyMatch(s -> s.startsWith("X"));

			System.out.println(result);

			System.out.println("#######################################");
			
			Optional<String> val = li.stream()
			        .filter(s -> s.startsWith("N")).findFirst();
			        

			System.out.println(val.get());
          
			System.out.println("#######################################");
			
			Optional<String> result1 = li.stream()
			        .reduce((a, b) -> a + "---" + b);

			System.out.println(result1.get());
			System.out.println("#######################################");
	

			List<String> li8 = li.stream()
			        .filter(s -> s.startsWith("N"))
			        .map(s -> s.toUpperCase())
			        .sorted()
			        .collect(Collectors.toList());

			System.out.println(li8);
			
			System.out.println("#######################################");
			
//			 li.stream()
//			        .filter(s -> s.startsWith("N"))
//			        .map(s -> s.toUpperCase())
//			        .sorted()
//			        .forEach(s -> System.out.println(s));
//
//			System.out.println(li);
			
			
			Set<String> set = li.stream()
			        .collect(Collectors.toSet());

			System.out.println(set);




	}

}
