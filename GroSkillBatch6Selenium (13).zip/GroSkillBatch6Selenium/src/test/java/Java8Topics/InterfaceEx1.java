package Java8Topics;

@FunctionalInterface
interface I1
{
	
	void display();
	
	
	
	static void test()
	{
		System.out.println("Hey");
	}
	
	
	
	 default void test2()
	{
		System.out.println("Java");
	}
	
	
}

class C1 implements I1
{
	public void display()
	{
		System.out.println("Hello");
	}
	
	
}



public class InterfaceEx1 {

	public static void main(String[] args) {
		
		I1 ref=new C1();
		ref.display();
		ref.test2();
		I1.test();
		

	}

}
