package Java8Topics;

import java.util.Arrays;
import java.util.List;

public class UsingForEachMethod {

	public static void main(String[] args) {
		
		
		List<String> li = Arrays.asList("Ram", "Shyam", "John");

        li.forEach(name -> System.out.println(name));

	}

}
