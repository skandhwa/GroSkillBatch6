package Java8Topics;

interface I5
{
	int getLengthOfString(String str);
}

//class A5 implements I5
//{
//	public int getLengthOfString(String str)
//	{
//		return str.length();
//	}
//}



public class UsingLambdaExpression3 {

	public static void main(String[] args) {
		
	    I5 ref=      (str)-> str.length();
	    
	System.out.println(ref.getLengthOfString("Saurabh"));    
		

	}

}
