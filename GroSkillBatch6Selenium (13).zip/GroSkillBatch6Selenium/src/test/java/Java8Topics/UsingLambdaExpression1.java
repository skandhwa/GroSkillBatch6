package Java8Topics;

@FunctionalInterface
interface I3
{
	public int sum(int a,int b);
}

//class C3 implements I3
//{
//	public int sum(int a,int b)
//	{
//		return a+b;
//	}
//}





public class UsingLambdaExpression1 {

	public static void main(String[] args) 
	{
	I3 ref=	(a,b) -> (a+b);
	System.out.println(ref.sum(12, 45));

	}

}