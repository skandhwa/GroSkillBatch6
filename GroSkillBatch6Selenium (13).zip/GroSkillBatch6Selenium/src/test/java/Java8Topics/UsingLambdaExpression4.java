package Java8Topics;

@FunctionalInterface
interface I6
{
	public int sum(int a,int b,int c,int d,int e);
	int x=30;
	
}

//class A6 implements I6
//{
//	public int sum(int a,int b,int c,int d,int e)
//	{
//		 c=a+b;
//		 d=c+e;
//		 return d;
//		
//	}
//}


public class UsingLambdaExpression4 {

	public static void main(String[] args) {
		
		I6 ref=	(a,b,c,d,e) ->
		{
			c=a+b;
			d=c+e;
			return d;
		};
		
	System.out.println(ref.sum(12, 20, 30, 40, 50));	
		
		
		
		

	}

}
