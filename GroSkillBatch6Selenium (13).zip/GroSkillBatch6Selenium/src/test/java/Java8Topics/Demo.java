package Java8Topics;

import java.time.LocalDate;

public class Demo {
	
	public static void main(String[] args) {
        LocalDate today = LocalDate.now();
        System.out.println("Today: " + today);

        LocalDate specificDate = LocalDate.of(2026, 6, 7);
        System.out.println("Specific Date: " + specificDate);
        
    System.out.println(today.getYear());    
    System.out.println   ( today.getMonth());
    System.out.println   (today.getDayOfMonth());

    System.out.println   (today.plusDays(5));
    

        
        
    }
}



