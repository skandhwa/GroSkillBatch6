package Java8Topics;

@FunctionalInterface
interface I4
{
	void test();
}

//class C4 implements I4
//{
//	public void test()
//	{
//		System.out.println("Hello");
//	}
//}

public class UsingLambdaExpression2 {

	public static void main(String[] args) {
		
	I4 ref=	()-> System.out.println("Hello");
	ref.test();
		

	}

}
