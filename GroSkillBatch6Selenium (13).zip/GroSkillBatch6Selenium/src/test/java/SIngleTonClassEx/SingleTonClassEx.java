package SIngleTonClassEx;

class SingleTonEx
{
	private static SingleTonEx inst;
	
	private SingleTonEx()
	{
		System.out.println("Instance created for class");
	}
	
	public static SingleTonEx getInstance()
	{
		if(inst==null)
		{
			inst=new SingleTonEx();
		}
		
		return inst;
	}
	


public void test()
{
	System.out.println("Hello");
}

}


public class SingleTonClassEx {

	public static void main(String[] args) {
		
		//SingleTonEx.getInstance().test();
		
		SingleTonEx s1=SingleTonEx.getInstance();
		SingleTonEx s2=SingleTonEx.getInstance();
		System.out.println(s1==s2);

	}

}
