package SIngleTonClassEx;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class DriverFactory {

    // Singleton instance
    private static DriverFactory instance = new DriverFactory();

    // ThreadLocal for parallel execution
    private static ThreadLocal<WebDriver> driver = new ThreadLocal<>();

    // Private constructor
    private DriverFactory() {
    }

    // Get singleton instance
    public static DriverFactory getInstance() {
        return instance;
    }

    // Initialize driver
    public void initDriver(String browser) {

        if (driver.get() == null) {

            switch (browser.toLowerCase()) {

            case "chrome":
                driver.set(new ChromeDriver());
                break;

            case "firefox":
                driver.set(new FirefoxDriver());
                break;

            case "edge":
                driver.set(new EdgeDriver());
                break;

            default:
                throw new IllegalArgumentException("Browser not supported: " + browser);
            }

            getDriver().manage().window().maximize();
            getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        }
    }

    // Get driver
    public WebDriver getDriver() {
        return driver.get();
    }

    // Quit driver
    public void quitDriver() {

        if (driver.get() != null) {
            driver.get().quit();
            driver.remove();
        }
    }
}