package SIngleTonClassEx;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Test123 extends Logintest{
	
	    @Test
	    public void googleTest() 
	    {

	        driver.get("https://www.google.com");
	        Assert.assertEquals(driver.getTitle(), "Google");
	    }

}
