package SIngleTonClassEx;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class Logintest {

    protected WebDriver driver;

    @BeforeMethod
    public void setUp() {

        DriverFactory.getInstance().initDriver("chrome");
        driver = DriverFactory.getInstance().getDriver();
    }

    @AfterMethod
    public void tearDown() {

        DriverFactory.getInstance().quitDriver();
    }
}