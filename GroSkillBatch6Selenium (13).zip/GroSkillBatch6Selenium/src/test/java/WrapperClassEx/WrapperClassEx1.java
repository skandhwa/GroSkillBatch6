package WrapperClassEx;

public class WrapperClassEx1 {

	public static void main(String[] args) {

       String str="123";
       
       int n= Integer.parseInt(str);
       
       System.out.println(n);
		

	}

}
