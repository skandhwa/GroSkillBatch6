package WrapperClassEx;

public class ConvertStringToWrapper {

	public static void main(String[] args) {
		
		String str="200";
		
		Integer x=Integer.valueOf(str);
		
		//Float y=Float.valueOf(str);
		System.out.println(x);
		
		System.out.println(Integer.MAX_VALUE);
		System.out.println(Integer.MIN_VALUE);

	}

}
