package CharacterClassEx;

public class CharacterClassEx1 {

	public static void main(String[] args) {
		
	    String str="test1234@abcd";
	    
	    char []ch=str.toCharArray();
	    
	   
	    
	    for(char x:ch)
	    {
	    	if((!Character.isAlphabetic(x)) && !Character.isDigit(x))
	    	{
	    		System.out.print(x);
	    	}
	    	
	    	
	    	
	    }
		

	}

}
