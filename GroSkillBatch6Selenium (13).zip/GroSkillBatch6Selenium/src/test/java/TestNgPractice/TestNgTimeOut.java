package TestNgPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class TestNgTimeOut 
{
    @Test(timeOut=5000)
    public void test() throws InterruptedException
    {
    	WebDriver driver=new ChromeDriver();
    	driver.get("https://www.google.com");
    	driver.manage().window().maximize();
    	
    	Thread.sleep(5000);
    	String title=driver.getTitle();
    	System.out.println(title);
    	
    }
    
	
	
	
	
}
