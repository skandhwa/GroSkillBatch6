package TestNgPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class TestNgParallelEx2 {
	
	@Test
	public void openInstagram()
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.instagram.com");
		driver.manage().window().maximize();
		
		
	}
	
	@Test
	public void openLinkedin()
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.linkedin.com");
		driver.manage().window().maximize();
		
		
	}
	
	@Test
	public void openAjio()
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.ajio.com");
		driver.manage().window().maximize();
		
		
	}
	
	@Test
	public void openAmazon()
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.amazon.com");
		driver.manage().window().maximize();
		
		
	}
	
	@Test
	public void openMeesho()
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.meesho.com");
		driver.manage().window().maximize();
		
		
	}
	
	@Test
	public void openFacebook()
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.facebook.com");
		driver.manage().window().maximize();
		
		
	}
	
	

}
