package TestNgPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class TestNgDPExample {
	
	
	@DataProvider(name="dp1")

	public Object [][] dpMethod()
	{

	return new Object [][]
	{

	{"Java"},{"Playwright"},{"Cypress"}


	};


	}
	
	@Test(dataProvider="dp1")
	public void searchGoogle(String x) throws InterruptedException
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com/");
		driver.manage().window().maximize();
	    WebElement ele=	driver.findElement(By.xpath("//*[@id='APjFqb']"));
	    ele.sendKeys(x);
	    ele.sendKeys(Keys.ENTER);
		Thread.sleep(3000);
		driver.quit();
		
		
		
		
	}
	
	
	

}
