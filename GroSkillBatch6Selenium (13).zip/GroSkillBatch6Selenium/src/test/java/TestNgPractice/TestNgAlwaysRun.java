package TestNgPractice;

import org.testng.annotations.Test;

public class TestNgAlwaysRun {
	
	@Test()
	public void logintest()
	{
		System.out.println("I am login test method");
		int x=9/0;
		System.out.println(x);
		
	}
	
	@Test(dependsOnMethods= {"logintest"},alwaysRun=true)
	public void SearchProducttest()
	{
		System.out.println("I am Search Product test method");
		int x=9/0;
		System.out.println(x);
	}

}
