package TestNgPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.ITestContext;
import org.testng.annotations.Test;

public class LoginTest {

    private WebDriver driver;

    private WebDriver getDriver(String browser) {

        String[] browsers = {
                "chrome",
                "firefox",
                "edge"
        };

        for (String b : browsers) {

            if (b.equalsIgnoreCase(browser)) {

                switch (b) {

                    case "chrome":
                        return new ChromeDriver();

                    case "firefox":
                        return new FirefoxDriver();

                    case "edge":
                        return new EdgeDriver();
                }
            }
        }

        throw new RuntimeException(
                "Unsupported browser: " + browser);
    }

    @Test(retryAnalyzer = BrowserRetryAnalyzer.class)
    public void loginTest(ITestContext context) {

        String browser =
                (String) context.getAttribute("browser");

        if (browser == null) {
            browser = "chrome"; // first execution
        }

        driver = getDriver(browser);

        try {

            driver.manage().window().maximize();

            driver.get("https://example.com");

            assert driver.getTitle()
                    .contains("Dashboard");

        } finally {

            if (driver != null) {
                driver.quit();
            }
        }
    }
}