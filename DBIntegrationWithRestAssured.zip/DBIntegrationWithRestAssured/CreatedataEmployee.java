package DBIntegrationWithRestAssured;

import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;
import static io.restassured.RestAssured.*;
import io.restassured.RestAssured;

public class CreatedataEmployee {

	public static void main(String[] args) throws SQLException {
		
		RestAssured.baseURI="https://reqres.in";
		
		Map<String,Object> mp=new LinkedHashMap<String,Object>();
		
		mp.put("ID",DBConnectionCode.DbConnection(1));
		mp.put("last_name",DBConnectionCode.DbConnection(2));
		mp.put("first_name",DBConnectionCode.DbConnection(3));
		mp.put("Address",DBConnectionCode.DbConnection(4));
		mp.put("City",DBConnectionCode.DbConnection(5));
		
String Response=		given().log().all().body(mp).
headers("Content-Type","application/json")
		.when().post("api/users")
		.then().assertThat().statusCode(201).extract().response().
		asString();
		
System.out.println(Response);
		
		

	}

}
