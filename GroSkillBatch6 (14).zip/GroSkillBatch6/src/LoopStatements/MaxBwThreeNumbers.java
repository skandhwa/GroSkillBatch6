package LoopStatements;

public class MaxBwThreeNumbers {

	public static void main(String[] args) {

       int a=12,b=150,c=30;
       
       if(a>b)
       {
    	   if(a>c)
    	   {
    		   System.out.println("a is maximum");
    		   
    	   }
    	   
    	   else
    	   {
    		   System.out.println("c is maximum");
    	   }
       }
       
       else
       {
    	   if(b>c)
    	   {
    		   System.out.println("b is maximum");
    	   }
    	   else
    	   {
    		   System.out.println("c is maximum");
    	   }
       }

	}

}
