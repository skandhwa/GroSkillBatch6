package LoopStatements;

public class ArmStrongNumberEx {

	public static void main(String[] args) {
		
		int num=407;
		
		int t=num;
		
		int sum=0;
		
		while(num!=0)//15!=0//1!=0//0!=0
		{
			int d=num%10;//d=153%10=3 // d=15%10=5 /// d=1%10=1
			
			sum= sum+ d*d*d;//sum=0+ 3*3*3=27 //sum=27+125=152//sum=152+1=153
			
			num=num/10;//num=153/10=15 //num=15/10=1 //num=1/10=0
		}
		
		if(sum==t) /// 153=153
		{
			System.out.println("It is an armstrong number");
		}
		else
		{
			System.out.println("It is not an armstrong number");
		}
		

	}

}
