package LoopStatements;

public class FactorialNumber {

	public static void main(String[] args) {
		
		int n=78;
		
		double fact=1;
		
		int i=1;
		
		do
		{
			fact=fact*i; //fact=1*1=1//fact=1*2=2///fact=2*3=6//fact=6*4=24//fact=24*5=120
			i++;///1++//2++//3++//4++//5++
		}
		
		while(i<=n);//2<=5//3<=5//4<=5//5<=5//6<=5
		
		System.out.println("Factorial of number is  "+fact);
		

	}

}
