package LoopStatements;

public class IfElseLogic {

	public static void main(String[] args) {
		
		int a=20,b=15,c=35;
		
		if(a>b && c>a && b<c)
		{
			System.out.println("It is true");
		}
		else
		{
			System.out.println("It is false");
		}
		
		

	}

}
