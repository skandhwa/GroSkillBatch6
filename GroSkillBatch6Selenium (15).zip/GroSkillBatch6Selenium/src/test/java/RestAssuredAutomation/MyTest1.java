package RestAssuredAutomation;

import static io.restassured.RestAssured.given;

import org.testng.internal.thread.ThreadTimeoutException;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class MyTest1 {

	public static void main(String[] args) throws ThreadTimeoutException {
		
		RestAssured.baseURI="https://reqres.in";
		
	 Response  res=	given().log().all().headers("content-type","application/json")
			.headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8").
		
		when().get("api/users")
		
		.then().log().all().assertThat().statusCode(200).
		extract().response();
	
	long time=res.getTime();
	
	
	if(time>5000)
	{
		throw new ThreadTimeoutException("Time limit exceeded");
	}
	
	else
	{
		System.out.println("Test scenario passed");
	}
	
	System.out.println(res.asString());
		
		
		
		
		

	}

}
