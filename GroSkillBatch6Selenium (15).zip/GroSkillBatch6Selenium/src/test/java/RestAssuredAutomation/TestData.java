package RestAssuredAutomation;

public class TestData {
	
	public static String getEmpData()
	{
		String payload="{\r\n"
				+ "  \"name\":\"harry\",\r\n"
				+ "  \"job\":\"manager\"\r\n"
				+ "\r\n"
				+ "\r\n"
				+ "}";
		
		return payload;
	}
	

}
