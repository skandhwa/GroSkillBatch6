package POJOPractice2;

import static io.restassured.RestAssured.given;

import org.testng.internal.thread.ThreadTimeoutException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class CreateEmployee2 {

	public static void main(String[] args) throws JsonProcessingException, ThreadTimeoutException {
		
		AddressPOJO add=new AddressPOJO();
		add.setZip(754678);
		add.setCity("New Delhi");
		add.setState("NCR");
		
		EmployeePOJO2 emp=new EmployeePOJO2();
		emp.setName("Harry");
		emp.setAge(45);
		emp.setMarried(true);
		emp.setSalary(90000);
		emp.setAddress(add);
		
		
		ObjectMapper obj=new ObjectMapper();
	String empJSON=	obj.writerWithDefaultPrettyPrinter().writeValueAsString(emp);
		
	RestAssured.baseURI="https://reqres.in";
	
	 Response  res=	given().log().all().headers("content-type","application/json")
			.headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8")
		.body(empJSON).
		when().post("api/users")
		
		.then().log().all().assertThat().statusCode(201).
		extract().response();
	
	long time=res.getTime();
	
	
	if(time>5000)
	{
		throw new ThreadTimeoutException("Time limit exceeded");
	}
	
	else
	{
		System.out.println("Test scenario passed");
	}
	
	System.out.println(res.asString());
		

	}

}
