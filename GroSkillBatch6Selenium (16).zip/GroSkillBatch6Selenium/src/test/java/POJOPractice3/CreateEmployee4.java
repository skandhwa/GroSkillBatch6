package POJOPractice3;

import static io.restassured.RestAssured.given;

import java.util.ArrayList;
import java.util.List;

import org.testng.internal.thread.ThreadTimeoutException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class CreateEmployee4 {

	public static void main(String[] args) throws ThreadTimeoutException, JsonProcessingException {
		
		List<String>li=new ArrayList<String>();
		li.add("ABC sweets");
		li.add("BKC mall");
		li.add("JB hotel");
		
		HdPojo hd=new HdPojo();
		hd.setFlatNo(23);
		hd.setApptName("CK appt");
		hd.setLandmark(li);
		hd.setStreet("MG marg");
		
		EmpAddPojo add=new EmpAddPojo();
		add.setCity("Delhi");
		add.setState("NCR");
		add.setZip(713308);
		add.setHdpojo(hd);
		
		List<String> bank=new ArrayList<String>();
		bank.add("Axis");
		bank.add("HDFC");
		bank.add("SBI");
		
		EmpPojo3 emp=new EmpPojo3();
		emp.setAge(34);
		emp.setName("Harry");
		emp.setMarried(false);
		emp.setSalary(90000);
		emp.setBanks(bank);
		emp.setEmpPojo(add);
		
		
		ObjectMapper obj=new ObjectMapper();
		String empJSON=	obj.writerWithDefaultPrettyPrinter().writeValueAsString(emp);
			
		RestAssured.baseURI="https://reqres.in";
		
		 Response  res=	given().log().all().headers("content-type","application/json")
				.headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8")
			.body(empJSON).
			when().post("api/users")
			
			.then().log().all().assertThat().statusCode(201).
			extract().response();
		
		long time=res.getTime();
		
		
		if(time>5000)
		{
			throw new ThreadTimeoutException("Time limit exceeded");
		}
		
		else
		{
			System.out.println("Test scenario passed");
		}
		
		System.out.println(res.asString());
		
		
		
		

	}

}
