package POJOPractice3;

import java.util.List;

public class HdPojo {
	
	private int flatNo;
	private String street;
	private List<String> landmark;
	private String apptName;
	
	public int getFlatNo() 
	{
		return flatNo;
	}
	public String getStreet() 
	{
		return street;
	}
	public List<String> getLandmark() 
	{
		return landmark;
	}
	public String getApptName() 
	{
		return apptName;
	}
	public void setFlatNo(int flatNo) 
	{
		this.flatNo = flatNo;
	}
	public void setStreet(String street) 
	{
		this.street = street;
	}
	public void setLandmark(List<String> landmark) 
	{
		this.landmark = landmark;
	}
	public void setApptName(String apptName) 
	{
		this.apptName = apptName;
	}
	
	
	
	
	
	
	
	

}
