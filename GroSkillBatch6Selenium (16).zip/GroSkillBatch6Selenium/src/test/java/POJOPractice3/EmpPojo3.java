package POJOPractice3;

import java.util.List;

public class EmpPojo3 {
	
	private String name;
	private int age;
	private long salary;
	private EmpAddPojo empPojo;
	private List<String> banks;
	private boolean isMarried;
	public String getName() {
		return name;
	}
	public int getAge() {
		return age;
	}
	public long getSalary() {
		return salary;
	}
	public EmpAddPojo getEmpPojo() {
		return empPojo;
	}
	public List<String> getBanks() {
		return banks;
	}
	public boolean isMarried() {
		return isMarried;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public void setSalary(long salary) {
		this.salary = salary;
	}
	public void setEmpPojo(EmpAddPojo empPojo) {
		this.empPojo = empPojo;
	}
	public void setBanks(List<String> banks) {
		this.banks = banks;
	}
	public void setMarried(boolean isMarried) {
		this.isMarried = isMarried;
	}
	
	
	
	

}
