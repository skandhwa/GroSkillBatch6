package POJOPractice3;

public class EmpAddPojo {
	
	private HdPojo hdpojo;
	private int zip;
	private String state;
	private String city;
	public HdPojo getHdpojo() 
	{
		return hdpojo;
	}
	public int getZip() 
	{
		return zip;
	}
	public String getState() 
	{
		return state;
	}
	public String getCity() 
	{
		return city;
	}
	public void setHdpojo(HdPojo hdpojo) 
	{
		this.hdpojo = hdpojo;
	}
	public void setZip(int zip) 
	{
		this.zip = zip;
	}
	public void setState(String state) 
	{
		this.state = state;
	}
	public void setCity(String city) 
	{
		this.city = city;
	}
	
	
	
	
	
	

}
