package MyPractice1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class HandlingDropDown {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Register.html");
		
	WebElement ele=	driver.findElement(By.id("Skills"));
	
	Select oselect=new Select(ele);
	
	oselect.selectByIndex(7);
	
	//oselect.selectByValue("Android");
//	oselect.selectByVisibleText("AutoCAD");
	
	
	
	
	
	
		
		

	}

}
