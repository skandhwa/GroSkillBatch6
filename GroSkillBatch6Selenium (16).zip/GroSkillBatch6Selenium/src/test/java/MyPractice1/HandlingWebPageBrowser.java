package MyPractice1;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingWebPageBrowser {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.flipkart.com/");
		
	List<WebElement> li=	driver.findElements(By.tagName("img"));
	
	int x=li.size();
	
	System.out.println("Total number of images are  "+x);
		
		

	}

}
