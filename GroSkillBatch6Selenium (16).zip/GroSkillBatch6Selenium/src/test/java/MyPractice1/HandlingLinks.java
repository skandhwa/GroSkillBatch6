package MyPractice1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingLinks {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com/");
	WebElement ele=	driver.findElement(By.xpath("//a[text()='Gmail']"));
	
	boolean flag=ele.isDisplayed();
	
	if(flag==true)
		
	{
		ele.click();
	}
	
	
	
	

	}

}
