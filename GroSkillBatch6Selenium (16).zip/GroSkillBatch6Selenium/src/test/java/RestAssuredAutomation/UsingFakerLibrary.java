package RestAssuredAutomation;

import static io.restassured.RestAssured.given;

import java.util.LinkedHashMap;
import java.util.Map;

import com.github.javafaker.Faker;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class UsingFakerLibrary {

	public static void main(String[] args) throws Exception {
		
		Faker fake=new Faker();
		
	
	String fullname=	fake.name().fullName();
	String emailAddress=	fake.internet().emailAddress();
	String phone=	fake.phoneNumber().cellPhone();
	long salary=	fake.number().randomNumber();
	
	Map<String,Object>mp=new LinkedHashMap<String,Object>();
	//mp.put("id", id);
	mp.put("name", fullname);
	mp.put("email", emailAddress);
	mp.put("contactNo", phone);
	mp.put("salary", salary);
	
	
	RestAssured.baseURI="https://reqres.in";
	
	 Response res=		given().log().all().
			headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8").
			headers("content-type","application/json").
			body(mp).
			
			
			
			when().post("api/users").
		    then().log().all().assertThat().statusCode(201)
		    .extract().response();
	 
	long time= res.getTime();
	
	System.out.println(time);
	
	if(time>5000)
	{
		throw new Exception("Time limit exceeded");
	}
	else
	{
		System.out.println("Test case passed");
	}
	 
	 

}

		

	

}
