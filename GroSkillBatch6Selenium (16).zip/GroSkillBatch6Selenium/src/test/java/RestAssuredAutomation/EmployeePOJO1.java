package RestAssuredAutomation;

public class EmployeePOJO1 {
	
	private String name;
	private String job;
	private boolean isMarried;
	private long salary;
	
	
	public String getName() 
	{
		return name;
	}
	public void setName(String name) 
	{
		this.name = name;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) 
	{
		this.job = job;
	}
	public boolean isMarried()
	{
		return isMarried;
	}
	public void setMarried(boolean isMarried) 
	{
		this.isMarried = isMarried;
	}
	public long getSalary() 
	{
		return salary;
	}
	public void setSalary(long salary) {
		this.salary = salary;
	}
	
	
	
	
	

}
