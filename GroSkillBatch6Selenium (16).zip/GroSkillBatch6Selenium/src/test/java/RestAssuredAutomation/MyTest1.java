package RestAssuredAutomation;

import static io.restassured.RestAssured.given;

import org.testng.Assert;
import org.testng.internal.thread.ThreadTimeoutException;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;


public class MyTest1 {

	public static void main(String[] args) throws ThreadTimeoutException {
		
		int tPages=2;
		RestAssured.baseURI="https://reqres.in";
		
	 Response  res=	given().log().all().headers("content-type","application/json")
			.headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8").
		
		when().get("api/users")
		
		.then().log().all().assertThat().statusCode(200).
		extract().response();
	
	long time=res.getTime();
	
	
	if(time>5000)
	{
		throw new ThreadTimeoutException("Time limit exceeded");
	}
	
	else
	{
		System.out.println("Test scenario passed");
	}
	
	String res1=res.asString();
	System.out.println(res1);
	
	
	JsonPath js=new JsonPath(res1);
int total_pages=	js.getInt("total_pages");
System.out.println(total_pages);

Assert.assertEquals(tPages, total_pages);



	
		
		
		
		
		

	}

}
