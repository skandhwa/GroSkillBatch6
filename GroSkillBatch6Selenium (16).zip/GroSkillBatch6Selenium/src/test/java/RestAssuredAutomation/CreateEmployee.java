package RestAssuredAutomation;

import static io.restassured.RestAssured.given;

import org.testng.internal.thread.ThreadTimeoutException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class CreateEmployee {

	public static void main(String[] args) throws JsonProcessingException, ThreadTimeoutException {
		
		EmployeePOJO1 emp=new EmployeePOJO1();
		emp.setJob("QA Manager");
		emp.setName("Harry");
		emp.setMarried(false);
		emp.setSalary(90000);
		
	ObjectMapper obj=new ObjectMapper();
	
	String empJSON=obj.writerWithDefaultPrettyPrinter().writeValueAsString(emp);
	
	RestAssured.baseURI="https://reqres.in";
	
	 Response  res=	given().log().all().headers("content-type","application/json")
			.headers("x-api-key","reqres_73341f65a30249bd9da6fb7fca0105a8")
		.body(empJSON).
		when().post("api/users")
		
		.then().log().all().assertThat().statusCode(201).
		extract().response();
	
	long time=res.getTime();
	
	
	if(time>5000)
	{
		throw new ThreadTimeoutException("Time limit exceeded");
	}
	
	else
	{
		System.out.println("Test scenario passed");
	}
	
	System.out.println(res.asString());
	
	
	
		
	
	
		

	}

}
