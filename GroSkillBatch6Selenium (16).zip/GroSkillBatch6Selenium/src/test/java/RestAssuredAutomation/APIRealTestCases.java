package RestAssuredAutomation;

import org.testng.Assert;

import io.restassured.path.json.JsonPath;

public class APIRealTestCases {

	public static void main(String[] args) {
		
		JsonPath js=new JsonPath(TestData.booksData());
		
		/// Print No of courses returned by API

		int courseSize=js.getInt("courses.size()");
		System.out.println("Total courses are  "+courseSize);
		
		//Print Purchase Amount
		
		int Purchaseamount= js.getInt("dashboard.purchaseAmount");
		System.out.println("Total purchase amount is  "+Purchaseamount);
		
		//Print Title of the first course
		
		String title=js.getString("courses[0].title");
		System.out.println("Title of first course is  "+title);
		
		
        /// Print All course titles and their respective Prices

		System.out.println("Course Title and their prices are ");
		
		for(int i=0;i<courseSize ;i++)
		{
			System.out.print(js.getString("courses["+i+"].title")+" ");
			System.out.println(js.getInt("courses["+i+"].price"));
			
		}
		
		
		///Print no of copies sold by RPA Course

		System.out.println("Copies sold by RPA are:");

		for (int i = 0; i < courseSize; i++) {
		    String courseTitle = js.getString("courses[" + i + "].title").trim();

		    if ("RPA".equalsIgnoreCase(courseTitle)) {
		        int copies = js.getInt("courses[" + i + "].copies");
		        System.out.println("Total number of copies: " + copies);
		        break;
		    }
		}
		
		
		/// Verify if Sum of all Course prices matches with Purchase Amount

		int sum=0;

		
		for(int i=0;i<courseSize ;i++)
		{
	int copies=	js.getInt("courses["+i+"].copies");
	int prices=	js.getInt("courses["+i+"].price");
	int amount=copies*prices;
	sum=sum+amount;

			
		}
		System.out.println("Total sum is  "+sum);
		Assert.assertEquals(Purchaseamount, sum);
		System.out.println("Assertions passed");
		

	}

}
